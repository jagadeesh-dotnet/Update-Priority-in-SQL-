import { AfterViewChecked, Component, OnInit } from '@angular/core';
import MultiRootEditor from '@ckeditor/ckeditor5-build-multi-root';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements  OnInit,AfterViewChecked{
  title = 'testapp';
  datajson={}; 

  ngOnInit(): void {

    for (let i = 0; i < this.pages.length; i++) {
      this.datajson["content-" + i]=document.getElementById( "content-" + i );
  
    }

    MultiRootEditor
        .create( 
          //{
            // Define roots / editable areas:
            //header: document.getElementById( 'header' ),
            //'content': document.getElementById( 'content' ),
            //'content1': document.getElementById( 'content1' ),
            //leftSide: document.getElementById( 'left-side' ),
            //rightSide: document.getElementById( 'right-side' )
        //}
        this.datajson
        )
        .then( editor => {
            window.editor = editor;

            // Append toolbar to a proper container.
            const toolbarContainer = document.getElementById( 'toolbar' );
            toolbarContainer.appendChild( editor.ui.view.toolbar.element );

            // Make toolbar sticky when the editor is focused.
            editor.ui.focusTracker.on( 'change:isFocused', () => {
                if ( editor.ui.focusTracker.isFocused ) {
                    toolbarContainer.classList.add( 'sticky' );
                } else {
                    toolbarContainer.classList.remove( 'sticky' );
                }
            } );
        } )
        .catch( error => {
            console.error( 'There was a problem initializing the editor.', error );
        } );

  }


  

  sizePage = {
    width: 21, //cm
    height: 29.7, //cm
  };
  paddingPage = {
    top: 2, //cm
    right: 2, //cm
    bottom: 2, //cm
    left: 2, //cm
  };
  pages = [
    {
      htmlContent: "",
      full: false,
    },
  ];
  currentPage = 0;
  currentChar = null;

  runAfterViewChecked = false;
  public Editor = MultiRootEditor;
  clickPage(i) {
    this.currentPage = i;
  }

  inputContent(char, i) {
    var element = document.getElementById("content-" + i);
    var heightContent = (element!.offsetHeight * 2.54) / 96; // Convert pixels to cm
    this.pages[i].htmlContent = element?element.innerHTML:'';
    console.log(this.pages);
    if (Number(heightContent.toFixed(1)) > this.sizePage.height) {
      this.currentChar = char;
      this.pages[i].full = true;
      if (!this.pages[i + 1]) {
        this.pages.push({
          htmlContent: "",
          full: false,
        });
      }
      this.currentPage = i + 1;
      this.runAfterViewChecked = true;
    }
  }


  ngAfterViewChecked() {

    document.getElementById("content-" + this.currentPage)!.focus();
    if (this.runAfterViewChecked) {
      if (this.currentChar) {
        var str = this.pages[this.currentPage - 1].htmlContent;
        var indexLastCloseDiv = str.lastIndexOf("</div>");
        var indexLastBr = str.lastIndexOf("<br>");
        var lastChar = str[indexLastCloseDiv - 1];
        if (indexLastBr != -1 && indexLastBr + 4 == indexLastCloseDiv)
          lastChar = " ";

        if (indexLastCloseDiv != -1)
          str =
            str.slice(0, indexLastCloseDiv - 1) + str.slice(indexLastCloseDiv);
        else str = str.slice(0, str.length - 1);
        this.pages[this.currentPage - 1].htmlContent = str;

        if (this.pages[this.currentPage].htmlContent)
          this.pages[this.currentPage].htmlContent =
            lastChar + this.pages[this.currentPage].htmlContent;
        else this.pages[this.currentPage].htmlContent = lastChar;
      }

      var element;
      for (let i = 0; i < this.pages.length; i++) {
        element = document.getElementById("content-" + i);
        element.innerHTML = this.pages[i].htmlContent;
        //this.datajson["content-" + i]=document.getElementById( "content-" + i );
    
      }
      this.runAfterViewChecked = false;
    }
    
  }
}