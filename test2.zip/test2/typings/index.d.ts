export {};

declare global {
  interface Window {
    editor: any;
  }
}