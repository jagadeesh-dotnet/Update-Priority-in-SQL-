﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ScheduleJobs
{
    class Program
    {
        static SmtpClient SmtpClient { get; set; }
        static Program()
        {
            SmtpClient = new SmtpClient(ConfigurationManager.AppSettings["smtpSettingshost"])
            {
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(
                    ConfigurationManager.AppSettings["smtpSettingsusername"],
                    ConfigurationManager.AppSettings["smtpSettingspassword"])
            };
        }

        static void Main(string[] args)
        {
            int delayBetweenEmails = int.Parse(
            ConfigurationManager.AppSettings["delayBetweenEmailsMilliseconds"]);

            using (var db = new EmailSchedulerEntities())
            {
                var data = db.Receipients.Where(r => r.SentStatus == 0).OrderBy(r=>r.Id).Take(8);

                foreach(Receipient recp in data)
                {
                    string email = recp.ReceipientEmail;
                    string personName = recp.FirstName +' '+recp.LastName;
                    var template = db.ScheduledTemplates.Where(t => t.Id == recp.ScheduledId).First();
                    string subject =template.Subject;
                    string bodyHtml = template.Body;
                    bodyHtml = bodyHtml.Replace("[name]", personName);
                    bool response=SendEmail(email, subject, bodyHtml);
                    if (response) recp.SentStatus = 1;
                    else recp.SentStatus = -1;

                    recp.SentOn = DateTime.Now;
                    db.SaveChanges();
                    Thread.Sleep(delayBetweenEmails);
                     
                }

            }
        }

        static bool SendEmail(string recipientEmail, string subject, string bodyHtml)
        {
            try { 
                var msg = new MailMessage
                {
                    From = new MailAddress(
                        ConfigurationManager.AppSettings["fromEmail"],
                        ConfigurationManager.AppSettings["fromName"]),
                    IsBodyHtml = true,
                    Body = bodyHtml,
                    BodyEncoding = Encoding.UTF8,
                    SubjectEncoding = Encoding.UTF8,
                    HeadersEncoding = Encoding.UTF8,
                    Subject = subject
                };
                msg.To.Add(recipientEmail);
                SmtpClient.Send(msg);
                return true;
            }catch(Exception ex)
            {
                return false;
            }
        }
    }
}
