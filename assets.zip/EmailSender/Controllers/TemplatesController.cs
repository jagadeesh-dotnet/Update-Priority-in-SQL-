﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using ClosedXML.Excel;
using EmailSender;
using EmailSender.Models;
using EmailSender.Utilities;

namespace EmailSender.Controllers
{
    public class TemplatesController : ApiController
    {
        private EmailSchedulerEntities db = new EmailSchedulerEntities();

        // GET: api/Templates
        public IHttpActionResult GetScheduledTemplates()
        {
            //return db.ScheduledTemplates;

            var data = from t in db.ScheduledTemplates.AsEnumerable()
                       select new
                       {
                           t.Id,
                           t.TemplateName,
                           t.Subject,
                           ScheduledOn = t.ScheduledOn.ToString("dd/MM/yyyy hh:mm tt"),
                           Status= t.Status == 0 ? "Not started" : t.Status == 1 ? "Started" : t.Status == 2 ? "Completed" : "Cancelled",
                           CreatedOn=t.CreatedOn.Value.ToString("dd/MM/yyyy hh:mm tt"),
                           SentCount = db.Receipients.Where(r => r.ScheduledId == t.Id && r.SentStatus == 1).Count()
                       };

            return Ok(data);
        }

        // GET: api/Templates/5
        [ResponseType(typeof(ScheduledTemplate))]
        public IHttpActionResult GetScheduledTemplate(int id)
        {
            var scheduledTemplate = from t in db.ScheduledTemplates.AsEnumerable()
                                    where t.Id == id
                                    select new
                                    {
                                        t.Id,
                                        t.TemplateName,
                                        t.Subject,
                                        t.Body,
                                        ScheduledOn = t.ScheduledOn.ToString("dd/MM/yyyy hh:mm tt"),
                                        ScheduledDate=t.ScheduledOn,
                                        Status = t.Status == 0 ? "Not started" : t.Status == 1 ? "Started" : t.Status == 2 ? "Completed" : "Cancelled",
                                        CreatedOn = t.CreatedOn.Value.ToString("dd/MM/yyyy hh:mm tt"),
                                        SentCount = db.Receipients.Where(r => r.ScheduledId == t.Id && r.SentStatus == 1).Count()
                                    };
            if (scheduledTemplate == null)
            {
                return NotFound();
            }

            return Ok(scheduledTemplate);
        }

        // PUT: api/Templates/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutScheduledTemplate(int id, ScheduledTemplate scheduledTemplate)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != scheduledTemplate.Id)
            {
                return BadRequest();
            }

            db.Entry(scheduledTemplate).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScheduledTemplateExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpPost]
        // POST: api/Templates
        [ResponseType(typeof(ScheduledTemplate))]
        public async Task<IHttpActionResult> PostScheduledTemplateAsync()
        {
            //if (!ModelState.IsValid)
            //{
            //    return BadRequest(ModelState);
            //}
            Template scheduledTemplate = new Template();

            // Check if the request contains multipart/form-data.  
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            var provider = await Request.Content.ReadAsMultipartAsync<InMemoryMultipartFormDataStreamProvider>(new InMemoryMultipartFormDataStreamProvider());
            //access form data  
            NameValueCollection formData = provider.FormData;

            //Fetch the File.
            HttpFileCollection postedFiles = HttpContext.Current.Request.Files;
            //Checking file content length and Extension must be .xlsx  
            if (postedFiles.Count > 0 && System.IO.Path.GetExtension(postedFiles[0].FileName).ToLower().Contains(".xl"))
            {


                ScheduledTemplate template = new ScheduledTemplate();
                template.TemplateName = formData.Get("templateName");
                template.Subject = formData.Get("subject");

                var scheduleDate = DateTime.ParseExact(formData.Get("scheduledOn"), "d/M/yyyy h:m", CultureInfo.CurrentCulture);
                template.ScheduledOn = scheduleDate;
                template.Body = formData.Get("body");
                template.CreatedOn = DateTime.Now;

                db.ScheduledTemplates.Add(template);
                db.SaveChanges();

                string path = Path.Combine(System.Web.Hosting.HostingEnvironment.MapPath("~/Uploads"), Path.GetFileName(postedFiles[0].FileName));
                //Saving the file  
                postedFiles[0].SaveAs(path);

                //Started reading the Excel file.  
                using (XLWorkbook workbook = new XLWorkbook(path))
                {
                    List<Receipient> receipients = new List<Receipient>();
                    IXLWorksheet worksheet = workbook.Worksheet(1);
                    bool FirstRow = true;
                    //Range for reading the cells based on the last cell used.  
                    string readRange = "1:1";
                    foreach (IXLRow row in worksheet.RowsUsed())
                    {
                        //If Reading the First Row (used) then add them as column name  
                        if (FirstRow)
                        {
                            //Checking the Last cellused for column generation in datatable  
                            //readRange = string.Format("{0}:{1}", 1, row.LastCellUsed().Address.ColumnNumber);
                            //foreach (IXLCell cell in row.Cells(readRange))
                            //{
                            //    dt.Columns.Add(cell.Value.ToString());
                            //}
                            FirstRow = false;
                        }
                        else
                        {
                            //Adding a Row  
                            Receipient receipient = new Receipient();
                            int cellIndex = 0;
                            //Updating the values of datatable  
                            foreach (IXLCell cell in row.Cells())
                            {
                                receipient.ScheduledId = template.Id;
                                if (cellIndex==0)
                                receipient.FirstName = cell.Value.ToString();
                                if (cellIndex == 1)
                                    receipient.LastName = cell.Value.ToString();
                                if (cellIndex == 2)
                                    receipient.ReceipientEmail = cell.Value.ToString().Trim();

                                cellIndex++;
                            }
                            receipients.Add(receipient);
                        }
                    }

                    db.Receipients.AddRange(receipients);
                    db.SaveChanges();
                }
            }


            return CreatedAtRoute("DefaultApi", new { id = scheduledTemplate.TemplateId }, scheduledTemplate);
        }

        // DELETE: api/Templates/5
        [ResponseType(typeof(ScheduledTemplate))]
        public IHttpActionResult DeleteScheduledTemplate(int id)
        {
            ScheduledTemplate scheduledTemplate = db.ScheduledTemplates.Find(id);
            if (scheduledTemplate == null)
            {
                return NotFound();
            }

            db.ScheduledTemplates.Remove(scheduledTemplate);
            db.SaveChanges();

            return Ok(scheduledTemplate);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ScheduledTemplateExists(int id)
        {
            return db.ScheduledTemplates.Count(e => e.Id == id) > 0;
        }
    }
}