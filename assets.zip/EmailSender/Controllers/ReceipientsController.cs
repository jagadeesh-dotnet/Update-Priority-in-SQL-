﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using EmailSender;

namespace EmailSender.Controllers
{
    public class ReceipientsController : ApiController
    {
        private EmailSchedulerEntities db = new EmailSchedulerEntities();

        // GET: api/Receipients/scheduleId(5)
        public IHttpActionResult GetReceipients(int scheduleId)
        {
            var data= from r in db.Receipients.AsEnumerable()
                      where r.ScheduledId==scheduleId
                      select new
                      {
                          r.Id,
                          r.FirstName,
                          r.LastName,
                          r.ReceipientEmail,
                          SentStatus=r.SentStatus==1?"True":"False",
                          SentOn = r.SentOn==null?"": r.SentOn.Value.ToString("dd/MM/yyyy hh:mm tt"),
                          ReadStatus = r.ReadStatus == 1 ? "True" : "False",
                          ReadOn = r.ReadOn==null?"":r.ReadOn.Value.ToString("dd/MM/yyyy hh:mm tt")
                      };

            return Ok(data);
        }

        // GET: api/Receipients/5
        //[ResponseType(typeof(Receipient))]
        //public IHttpActionResult GetReceipient(int id)
        //{
        //    Receipient receipient = db.Receipients.Find(id);
        //    if (receipient == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(receipient);
        //}

        // PUT: api/Receipients/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutReceipient(int id, Receipient receipient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != receipient.Id)
            {
                return BadRequest();
            }

            db.Entry(receipient).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ReceipientExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Receipients
        [ResponseType(typeof(Receipient))]
        public IHttpActionResult PostReceipient(Receipient receipient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Receipients.Add(receipient);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = receipient.Id }, receipient);
        }

        // DELETE: api/Receipients/5
        [ResponseType(typeof(Receipient))]
        public IHttpActionResult DeleteReceipient(int id)
        {
            Receipient receipient = db.Receipients.Find(id);
            if (receipient == null)
            {
                return NotFound();
            }

            db.Receipients.Remove(receipient);
            db.SaveChanges();

            return Ok(receipient);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ReceipientExists(int id)
        {
            return db.Receipients.Count(e => e.Id == id) > 0;
        }
    }
}