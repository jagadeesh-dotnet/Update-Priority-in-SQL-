﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmailSender.Models
{
    public class Template
    {
        public int TemplateId { get; set; }
        public string TemplateName { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string ScheduledOn { get; set; }
        public int Status { get; set; }
        public string CreatedOn { get; set; }
    }
}
