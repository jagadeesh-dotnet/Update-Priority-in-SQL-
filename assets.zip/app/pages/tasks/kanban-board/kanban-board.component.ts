import { Component, ViewChild } from '@angular/core';
import { ModalComponent } from 'src/app/shared/components/modals/modal-wrapper/modal/modal.component';
import { ModalConfig } from 'src/app/shared/models/modal-config';

@Component({
  selector: 'app-kanban-board',
  templateUrl: './kanban-board.component.html',
  styleUrls: ['./kanban-board.component.css']
})
export class KanbanBoardComponent {

  constructor(){}

  @ViewChild('modal') private modal: ModalComponent
  public modalConfig: ModalConfig = {
    modalTitle: "Title",
    onDismiss: () => {
      return true
    },
    dismissButtonLabel: "Dismiss",
    onClose: () => {
      return true
    },
    closeButtonLabel: "Close"
  }

  async openModal() {
    return await this.modal.open()
  }
}
