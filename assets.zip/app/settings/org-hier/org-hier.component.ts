import { Component } from '@angular/core';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TreeNode } from 'angular13-organization-chart';

// make your own interface that extends TreeNode
interface MyTreeNode extends TreeNode {
  name: string;
  description?: string;
  image?: string;
  children: MyTreeNode[];
}


@Component({
  selector: 'app-org-hier',
  templateUrl: './org-hier.component.html',
  styleUrls: ['./org-hier.component.scss']
})
export class OrgHierComponent {

  closeResult = '';

	constructor(private modalService: NgbModal) {}

	open(content:any) {
		this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then(
			(result) => {
				this.closeResult = `Closed with: ${result}`;
			},
			(reason) => {
				this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
			},
		);
	}

	private getDismissReason(reason: any): string {
		if (reason === ModalDismissReasons.ESC) {
			return 'by pressing ESC';
		} else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
			return 'by clicking on a backdrop';
		} else {
			return `with: ${reason}`;
		}
	}
  
  tree: MyTreeNode = {
    name: 'Felines',
    description: 'Cute playful animals',
    image: 'assets/chart-images/1.png',
    onClick: () => alert('Death to dogs'),
    children: [
        {
            name: 'Big Cats',
            image: 'assets/chart-images/1.jpg',
            css: 'background-color: #F00000',
            children: [
                {
                    name: 'Lion',
                    image: 'assets/chart-images/1.png',
                    children: []
                },
                {
                    name: 'Tiger',
                    cssClass: 'yellow-on-hover',
                    image: 'assets/chart-images/4.jpg',
                    children: []
                },
                {
                    name: 'Cheetah',
                    image: 'assets/chart-images/8.png',
                    children: []
                }
            ]
        },
        {
            name: 'Small Cats',
            description: 'Cute, but can also be crude. Like when they defecate on your lap, that would be a good example of crudeness on their part',
            image: 'assets/chart-images/9.png',
            children: [
                {
                    name: 'House Cat',
                    image: 'assets/chart-images/7.png',
                    children: []
                },
                {
                    name: 'Street Cat',
                    image: 'assets/chart-images/8.png',
                    children: [
                        {
                            name: 'Dumb Cat',
                            image: 'assets/chart-images/13.png',
                            children: [
                                {
                                    name: 'Sorry For Bad Example',
                                    image: 'assets/chart-images/6.png',
                                    children: []
                                }
                            ],
                        },
                        {
                            name: 'Good Cat',
                            image: 'assets/chart-images/8.png',
                            children: [
                                {
                                    name: 'Binary Search Tree',
                                    image: 'assets/chart-images/10.png',
                                    children: [
                                        {
                                            name: '7',
                                            image: 'assets/chart-images/11.png',
                                            children: [
                                                {
                                                    name: '3',
                                                    image: 'assets/chart-images/6.png',
                                                    children: [
                                                        {
                                                            name: '2',
                                                            image: 'assets/chart-images/7.png',
                                                            children: []
                                                        },
                                                        {
                                                            name: '5',
                                                            image: 'assets/chart-images/12.png',
                                                            children: []
                                                        }
                                                    ]
                                                },
                                                {
                                                    name: '13',
                                                    description: 'An odd yet funny number.',
                                                    image: 'assets/chart-images/14.png',
                                                    children: [
                                                        {
                                                            name: '11',
                                                            description: 'All nodes to the right are greater',
                                                            image: 'assets/chart-images/15.png',
                                                            children: []
                                                        },
                                                        {
                                                            name: '17',
                                                            image: 'assets/chart-images/13.png',
                                                            description: 'This number is less that 17.00000001',
                                                            children: []
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        {
            name: 'Fake Cats',
            image: 'assets/chart-images/5.png',
            children: [],
            onClick: () => console.log('Google chrome stole some RAM')
        }
    ]
};

}
