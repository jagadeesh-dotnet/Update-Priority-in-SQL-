import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditHierarchyComponent } from './add-edit-hierarchy.component';

describe('AddEditHierarchyComponent', () => {
  let component: AddEditHierarchyComponent;
  let fixture: ComponentFixture<AddEditHierarchyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditHierarchyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditHierarchyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
