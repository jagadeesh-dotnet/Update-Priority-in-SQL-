import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-edit-hierarchy',
  templateUrl: './add-edit-hierarchy.component.html',
  styleUrls: ['./add-edit-hierarchy.component.css']
})
export class AddEditHierarchyComponent implements OnInit, OnChanges {
  orgaArr:any[] = [];
  empArr:any[] = [];
  @Output() empdetails = new EventEmitter;
  employees:any[] = [];
  addFormGroup: FormGroup;

  constructor(private formBuilder: FormBuilder) {
    this.addFormGroup = this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(30)]],
      desg: ['', [Validators.required]],
      supervisor: ['', [Validators.required]]
    });

    this.orgaArr=[{
      "designation_name": "CEO",
      "designation_id": 1,
      "designation_parentid": 0
    },
    {
      "designation_name": "Director",
      "designation_id": 2,
      "designation_parentid": 1
    },
    {
      "designation_name": "Associate Director",
      "designation_id": 3,
      "designation_parentid": 2
    },
    {
      "designation_name": "Senior Manager",
      "designation_id": 4,
      "designation_parentid": 3
    },
    {
      "designation_name": "Manager",
      "designation_id": 5,
      "designation_parentid": 4
    },
    {
      "designation_name": "Senior Associate",
      "designation_id": 6,
      "designation_parentid": 5
    },
    {
      "designation_name": "Associate",
      "designation_id": 7,
      "designation_parentid": 6
    },
    {
      "designation_name": "PAT",
      "designation_id": 8,
      "designation_parentid": 7
    }];
  
     this.empArr=[{
      "empid": 1,
      "empname": "Luann Brannick",
      "parentid": 0,
      "empdesgid": 1,
      "supervisorid": 0,
      "empdesgname": "CEO"
    }
  ];
   
  }

  ngOnInit() {

  }

  ngOnChanges() {
    // console.log('this.employees => ', this.empArr);
  }

  addForm() {
    if (this.addFormGroup.valid) {
      console.log('this.addFormGroup.value => ', this.addFormGroup.value);
      this.addempdetails(this.addFormGroup.value);
    }
    console.log('this.addFormGroup => ', this.addFormGroup);
  }

  addempdetails(empdt:any) {
    const desgEle = this.orgaArr.filter(ele => ele.designation_id === parseInt(empdt.desg, 0));
    console.log('desgEle => ', desgEle);
    console.log('this.empArr => ', this.empArr);
    const empLen = this.empArr.length;
    const lastEmpId = this.empArr[empLen - 1].empid;
    const obj = {
      empid: lastEmpId + 1,
      empname: empdt.name,
      parentid: desgEle[0].designation_parentid,
      empdesgid: desgEle[0].designation_id,
      // tslint:disable-next-line:radix
      supervisorid: parseInt(empdt.supervisor),
      empdesgname: desgEle[0].designation_name
    };
    this.empArr.push(obj);
    console.log('this.empArr => ', this.empArr);
    this.empdetails.emit(this.empArr);
  }

  checksupervisors(desgid:any) {
    console.log(desgid);
    this.employees = this.empArr.filter(ele => ele.empdesgid === desgid - 1);
    console.log(this.employees);
  }

}
