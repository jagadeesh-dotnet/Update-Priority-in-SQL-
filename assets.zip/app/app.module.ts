import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MainComponent } from './main/main.component';
import { HeaderComponent } from './main/header/header.component';
import { FooterComponent } from './main/footer/footer.component';
import { MenuSidebarComponent } from './main/menu-sidebar/menu-sidebar.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProjectsListComponent } from './pages/projects/projects-list/projects-list.component';
import { ProjectDetailComponent } from './pages/projects/project-detail/project-detail.component';
import { CreateProjectComponent } from './pages/projects/create-project/create-project.component';
import { TaskListComponent } from './pages/tasks/task-list/task-list.component';
import { TaskDetailComponent } from './pages/tasks/task-detail/task-detail.component';
import { CreateTaskComponent } from './pages/tasks/create-task/create-task.component';
import { KanbanBoardComponent } from './pages/tasks/kanban-board/kanban-board.component';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    MainComponent,
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MenuSidebarComponent,
    DashboardComponent,
    ProjectsListComponent,
    ProjectDetailComponent,
    CreateProjectComponent,
    TaskListComponent,
    TaskDetailComponent,
    CreateTaskComponent,
    KanbanBoardComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    SharedModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
