import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MainComponent } from './main/main.component';
import { HeaderComponent } from './main/header/header.component';
import { FooterComponent } from './main/footer/footer.component';
import { MenuSidebarComponent } from './main/menu-sidebar/menu-sidebar.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProjectsListComponent } from './pages/projects/projects-list/projects-list.component';
import { ProjectDetailComponent } from './pages/projects/project-detail/project-detail.component';
import { CreateProjectComponent } from './pages/projects/create-project/create-project.component';
import { TaskListComponent } from './pages/tasks/task-list/task-list.component';
import { TaskDetailComponent } from './pages/tasks/task-detail/task-detail.component';
import { CreateTaskComponent } from './pages/tasks/create-task/create-task.component';
import { KanbanBoardComponent } from './pages/tasks/kanban-board/kanban-board.component';
import { SharedModule } from './shared/shared.module';
import { OrgHierComponent } from './settings/org-hier/org-hier.component';
import { OrgChartModule } from 'angular13-organization-chart';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { AddEditHierarchyComponent } from './settings/add-edit-hierarchy/add-edit-hierarchy.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateCompiler, TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateMessageFormatCompiler } from 'ngx-translate-messageformat-compiler';
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    MainComponent,
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MenuSidebarComponent,
    DashboardComponent,
    ProjectsListComponent,
    ProjectDetailComponent,
    CreateProjectComponent,
    TaskListComponent,
    TaskDetailComponent,
    CreateTaskComponent,
    KanbanBoardComponent,
    OrgHierComponent,
    AddEditHierarchyComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    SharedModule,
    OrgChartModule,
    DragDropModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule, 
    TranslateModule.forRoot({
      defaultLanguage: 'en',
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
      compiler: {
        provide: TranslateCompiler,
        useClass: TranslateMessageFormatCompiler
      }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
