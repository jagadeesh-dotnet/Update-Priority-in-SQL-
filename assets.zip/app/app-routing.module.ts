import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './main/main.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { CreateProjectComponent } from './pages/projects/create-project/create-project.component';
import { ProjectDetailComponent } from './pages/projects/project-detail/project-detail.component';
import { ProjectsListComponent } from './pages/projects/projects-list/projects-list.component';
import { CreateTaskComponent } from './pages/tasks/create-task/create-task.component';
import { KanbanBoardComponent } from './pages/tasks/kanban-board/kanban-board.component';
import { TaskDetailComponent } from './pages/tasks/task-detail/task-detail.component';
import { TaskListComponent } from './pages/tasks/task-list/task-list.component';


const routes: Routes = [
  {
      path: '',
      component: MainComponent,
      // canActivate: [AuthGuard],
      // canActivateChild: [AuthGuard],
      children: [
          // {
          //     path: 'profile',
          //     component: ProfileComponent
          // },
          // {
          //     path: 'blank',
          //     component: BlankComponent
          // },
          // {
          //     path: 'sub-menu-1',
          //     component: SubMenuComponent
          // },
          // {
          //     path: 'sub-menu-2',
          //     component: BlankComponent
          // },
          {
              path: '',
              component: DashboardComponent
          }
      ]
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'projects',
    component: ProjectsListComponent
  },
  {
    path: 'projects/detail',
    component: ProjectDetailComponent
  },
  {
    path: 'projects/create',
    component: CreateProjectComponent
  },
  {
    path: 'tasks',
    component: TaskListComponent
  },
  {
    path: 'task/detail',
    component: TaskDetailComponent
  },
  {
    path: 'tasks/create',
    component: CreateTaskComponent
  },
  {
    path: 'board',
    component: KanbanBoardComponent
  }
  
  // {
  //     path: 'login',
  //     component: LoginComponent,
  //     canActivate: [NonAuthGuard]
  // },
  // {
  //     path: 'register',
  //     component: RegisterComponent,
  //     canActivate: [NonAuthGuard]
  // },
  // {
  //     path: 'forgot-password',
  //     component: ForgotPasswordComponent,
  //     canActivate: [NonAuthGuard]
  // },
  // {
  //     path: 'recover-password',
  //     component: RecoverPasswordComponent,
  //     canActivate: [NonAuthGuard]
  // },
  ,{path: '**', redirectTo: ''}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
