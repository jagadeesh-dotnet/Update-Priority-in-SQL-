// import {AppState} from '@/store/state';
// import {ToggleControlSidebar, ToggleSidebarMenu} from '@/store/ui/actions';
// import {UiState} from '@/store/ui/state';
import {Component, HostBinding, OnInit} from '@angular/core';
import {UntypedFormGroup, UntypedFormControl} from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DefaultLangChangeEvent, LangChangeEvent, TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
// import {Store} from '@ngrx/store';
// import {AppService} from '@services/app.service';
import {Observable} from 'rxjs';

const BASE_CLASSES = 'main-header navbar navbar-expand';
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    //@HostBinding('class') classes: string = BASE_CLASSES;
    // public ui: Observable<UiState>;
    // public searchForm: UntypedFormGroup;
    closeResult:any='';
    constructor(
        // private appService: AppService,
        // private store: Store<AppState>
        private translate: TranslateService,
        private modalService: NgbModal
    ) {

        this.translate.onLangChange
        .subscribe((event: LangChangeEvent) => {
          console.log('onLangChange', event);
        });
  
      this.translate.onTranslationChange
        .subscribe((event: TranslationChangeEvent) => {
          console.log('onTranslationChange', event);
        });
  
      this.translate.onDefaultLangChange
        .subscribe((event: DefaultLangChangeEvent) => {
          console.log('onDefaultLangChange', event);
        });
    }

    changeSiteLanguage(localeCode: string): void {
        const selectedLanguage = this.languageList
          .find((language) => language.code === localeCode)
          ?.label.toString();
    
        if (selectedLanguage) {
          this.siteLanguage = selectedLanguage;
          this.translate.use(localeCode);
        }
    
        const currentLanguage = this.translate.currentLang;
        console.log('currentLanguage', currentLanguage);
      }

    ngOnInit() {
        // this.ui = this.store.select('ui');
        // this.ui.subscribe((state: UiState) => {
        //     this.classes = `${BASE_CLASSES} ${state.navbarVariant}`;
        // });
        // this.searchForm = new UntypedFormGroup({
        //     search: new UntypedFormControl(null)
        // });
    }

    logout() {
        //this.appService.logout();
    }

    siteLanguage = 'English';

  languageList = [
    { code: 'en', label: 'English',flag:'us.jpg' },
    { code: 'es', label: 'italy',flag:'italy.jpg' },
  ];

    onToggleMenuSidebar() {
        //this.store.dispatch(new ToggleSidebarMenu());
        var toggle = document.querySelector('html');
        var currentSelection= toggle?.getAttribute('data-sidenav-size');
        toggle?.setAttribute('data-sidenav-size', currentSelection=='default'?'condensed':'default');
    }

    onToggleControlSidebar() {
        //this.store.dispatch(new ToggleControlSidebar());
    }

	open(content:any) {
		this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then(
			(result:any) => {
				this.closeResult = `Closed with: ${result}`;
			},
			(reason:any) => {
				//this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
			},
		);
	}

}