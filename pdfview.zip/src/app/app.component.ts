import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { NgxExtendedPdfViewerModule, pdfDefaultOptions } from 'ngx-extended-pdf-viewer'

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,NgxExtendedPdfViewerModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent implements OnInit{
  title = 'pdfview';
  invoiceno:any='';
  pdfurl:any='assets/10840-001.pdf';
  
  constructor(private http: HttpClient) {

    pdfDefaultOptions.rangeChunkSize = 65536;
   }

  ngOnInit(): void {
  
  //   this.GenerateInvoicePDF(this.invoiceno).subscribe(res => {
  //     let blob: Blob = res.body as Blob;
  //     let url = window.URL.createObjectURL(blob);
  //     this.pdfurl = url;
  //     //window.open(url);
  //   });
  }

  GenerateInvoicePDF(invoiceno:any){
    return this.http.get('http://localhost:5011/weatherforecast/Downloadpdf',{observe:'response',responseType:'blob'});
  }

}
