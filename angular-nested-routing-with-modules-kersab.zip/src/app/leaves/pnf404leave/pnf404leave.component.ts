import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pnf404leave',
  templateUrl: './pnf404leave.component.html',
  styleUrls: ['./pnf404leave.component.css']
})
export class PNF404leaveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
