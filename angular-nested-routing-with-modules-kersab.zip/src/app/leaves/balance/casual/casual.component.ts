import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-casual',
  templateUrl: './casual.component.html',
  styleUrls: ['./casual.component.css']
})
export class CasualComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
