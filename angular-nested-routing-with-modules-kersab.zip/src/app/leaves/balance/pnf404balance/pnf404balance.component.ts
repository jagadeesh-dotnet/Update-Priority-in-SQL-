import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pnf404balance',
  templateUrl: './pnf404balance.component.html',
  styleUrls: ['./pnf404balance.component.css']
})
export class PNF404balanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
