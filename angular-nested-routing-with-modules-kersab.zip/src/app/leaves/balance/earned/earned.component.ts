import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-earned',
  templateUrl: './earned.component.html',
  styleUrls: ['./earned.component.css']
})
export class EarnedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
