import { NgModule } from "@angular/core";
import { AttendanceComponent } from './attendance.component';

@NgModule({
    declarations: [AttendanceComponent]
})
export class AttendanceModule {}