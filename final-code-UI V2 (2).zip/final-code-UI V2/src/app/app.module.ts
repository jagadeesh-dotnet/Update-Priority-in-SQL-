import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { GridAllModule, GridModule } from '@syncfusion/ej2-angular-grids';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { PivotViewAllModule, PivotFieldListAllModule, PivotViewModule, PivotFieldListModule } from '@syncfusion/ej2-angular-pivotview';
import { PageService, SortService, FilterService, GroupService } from '@syncfusion/ej2-angular-grids';
import { AppComponent } from './app.component';
import { MultiSelectAllModule, ListBoxAllModule } from '@syncfusion/ej2-angular-dropdowns';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    PivotViewModule,
    PivotFieldListModule,
    HttpClientModule,
    GridModule,
    GridAllModule,
    MultiSelectAllModule,
    ListBoxAllModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  providers: [PageService,
    SortService,
    FilterService,
    GroupService],
  bootstrap: [AppComponent]
})
export class AppModule { }
