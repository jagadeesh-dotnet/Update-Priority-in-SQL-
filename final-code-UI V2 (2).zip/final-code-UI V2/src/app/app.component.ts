import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import {
    IDataOptions, PivotView, FieldListService, CalculatedFieldService,
    ToolbarService, ConditionalFormattingService, ToolbarItems, DisplayOption, IDataSet,
    NumberFormattingService,
    DrillThroughService,
    IFieldOptions,
    VirtualScrollService
} from '@syncfusion/ej2-angular-pivotview';
import { GridSettings } from '@syncfusion/ej2-pivotview/src/pivotview/model/gridsettings';
import { enableRipple } from '@syncfusion/ej2-base/';
import { ChartSettings } from '@syncfusion/ej2-pivotview/src/pivotview/model/chartsettings';
import { ILoadedEventArgs, ChartTheme } from '@syncfusion/ej2-charts';
import { DataManager, WebApiAdaptor } from '@syncfusion/ej2-data';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as bootstrap from 'bootstrap';
import { GridComponent, GroupService, SortService } from '@syncfusion/ej2-angular-grids';
import { FieldSettingsModel, ListBox, MultiSelect, PopupEventArgs, ToolbarSettingsModel } from '@syncfusion/ej2-dropdowns';
import { animate, style, transition, trigger } from '@angular/animations';
declare var bootbox:any;
declare var Swal:any;
enableRipple(false);

/**
 * Pivot Table Toolbar Sample
 */
declare var require: any;
@Component({
    selector: 'app-root',
    templateUrl: 'app.component_1.html',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['app.component.css'],
    providers: [CalculatedFieldService,DrillThroughService,VirtualScrollService, ToolbarService, ConditionalFormattingService, FieldListService, NumberFormattingService, GroupService, SortService],
    // animations: [
    //     trigger(
    //       'inOutAnimation', 
    //       [
    //         transition(
    //           ':enter', 
    //           [
    //             style({ height: 0, opacity: 0 }),
    //             animate('3s ease-out', 
    //                     style({ height: 300, opacity: 1 }))
    //           ]
    //         ),
    //         transition(
    //           ':leave', 
    //           [
    //             style({ height: 300, opacity: 1 }),
    //             animate('3s ease-in', 
    //                     style({ height: 0, opacity: 0 }))
    //           ]
    //         )
    //       ]
    //     )
    //   ]
})
export class AppComponent {
    public dataSourceSettings: IDataOptions;
    public gridSettings: GridSettings;
    public toolbarOptions: ToolbarItems[];
    public toolbarOptionsDG: string[];
    public chartSettings: ChartSettings;
    public displayOption: DisplayOption;
    public observable = new Observable();
    public data: DataManager;
    public dataDG: DataManager;
    public initialSort: Object;
    filterType:String='3';
    currentmenu:string='';
    currentMenuName:string='Item Details';
    submitClicked:boolean=false;
    showPVGrid: boolean = false;
    showGridSection: boolean = false;
    public pageSettings: Object;
    public filterSettings: Object;
    templateselectedIndex:number=-1;
    currentTab: String;
     // map the groupBy field with category column
     public checkFields: Object = { text: 'Name', value: 'Code' };
     public countries: { [key: string]: Object }[] = [
        { Name: 'Ladieswear', Code: 'AU' },
        { Name: 'Kidswear', Code: 'BM' },
        { Name: 'Menswear', Code: 'CA' },
        { Name: 'Cameroon', Code: 'CM' },
        { Name: 'Denmark', Code: 'DK' },
        { Name: 'France', Code: 'FR' },
        { Name: 'Finland', Code: 'FI' },
        { Name: 'Germany', Code: 'DE' },
        { Name: 'Greenland', Code: 'GL' },
        { Name: 'Hong Kong', Code: 'HK' },
        { Name: 'India', Code: 'IN' },
        { Name: 'Italy', Code: 'IT' },
        { Name: 'Japan', Code: 'JP' },
        { Name: 'Mexico', Code: 'MX' },
        { Name: 'Norway', Code: 'NO' },
        { Name: 'Poland', Code: 'PL' },
        { Name: 'Switzerland', Code: 'CH' },
        { Name: 'United Kingdom', Code: 'GB' },
        { Name: 'United States', Code: 'US' }
    ];

    public Templatess=["Template 1", "Template 2","Test Template 3","Test Template 4","Test Template 5"];
    
 
    constructor(private http: HttpClient) {
        
    }

    GoToMenu(menu:string){
        this.currentmenu=menu;

        if(menu=='ItemDet'){     
            this.currentMenuName='Item Details';
            $('#slimScrollDiv').animate({scrollTop: 0 }, 300);
        }else{
            this.currentMenuName='Report On';
            $('#slimScrollDiv').animate({scrollTop: 1000 }, 300);
            //$('#slimScrollDiv').scrollTop(100);
        }
        (<any>$('#id-item-details-modal')).modal('show');
        this.templateselectedIndex=-1;
        this.showSelectedFilterModal('1');
        (<any>$('#id-ace-settings-modal')).modal('show');
        //$('#id-ace-settings-modal').modal('toggle');
    }

    showSelectedFilterModal(tabNo:string){
        this.currentTab=tabNo;
        (<any>$('#id-ace-settings-modal')).modal('show');
        
        $('#home14').removeClass('show active');
        $('#profile14').removeClass('show active');
        if(tabNo=='1'){
            this.templateselectedIndex=-1;
            //$('#sidebar, #id-item-details-modal').removeClass("disableddiv");  //disableDiv
            $('#templateModalDialog').removeClass("templatemodal-dialog");
            $('#home14').tab('show');
        }else{
            $('#profile14').tab('show');
        }
        //console.log(tabNo);
    }

    selectedTemplated(index:any){
        this.templateselectedIndex=index;
        //$('#sidebar, #id-item-details-modal').addClass("disableddiv");  //disableDiv
        $('#templateModalDialog').addClass("templatemodal-dialog");
    }

    resetIndex(){
        this.templateselectedIndex=-1;
    }

    onClose(e: PopupEventArgs) {
        //debugger;
        e.cancel = false;
    };
      
    removeDisabledcls(){
        debugger;
        //$('#sidebar, #id-item-details-modal').removeClass("disableddiv");   //disableDiv
    }
    saveTemplate(){
        bootbox.prompt({
            title: "<p class='text-orange-d2 mb-0'>Are you sure?</p><p class='text-80 text-secondary mb-0'>To save the selected filters please enter the \"template\" name below and then click \"OK\" to save</p>",
            onEscape: true,
            callback: function() {
              //console.log(result);
            }
        })
    }
     
    @ViewChild('pivotview')
    public pivotObj: PivotView;
    
    @ViewChild('grid')
    public grid: GridComponent;

    
  @ViewChild("listboxA", { static: false }) 
  public listObjA:ListBox;
  @ViewChild("listboxB", { static: false }) 
  public listObjB:ListBox;

    
    saveReport(args: any) {
        let reports = [];
        let isSaved: boolean = false;
        if (localStorage.pivotviewReports && localStorage.pivotviewReports !== "") {
            reports = JSON.parse(localStorage.pivotviewReports);
        }
        if (args.report && args.reportName && args.reportName !== '') {
            reports.map(function (item: any): any {
                if (args.reportName === item.reportName) {
                    item.report = args.report; isSaved = true;
                }
            });
            if (!isSaved) {
                reports.push(args);
            }
            localStorage.pivotviewReports = JSON.stringify(reports);
        }
    }
    fetchReport(args: any) {
        let reportCollection: string[] = [];
        let reeportList: string[] = [];
        if (localStorage.pivotviewReports && localStorage.pivotviewReports !== "") {
            reportCollection = JSON.parse(localStorage.pivotviewReports);
        }
        reportCollection.map(function (item: any): void { reeportList.push(item.reportName); });
        args.reportName = reeportList;
    }
    loadReport(args: any) {
        let reportCollection: string[] = [];
        if (localStorage.pivotviewReports && localStorage.pivotviewReports !== "") {
            reportCollection = JSON.parse(localStorage.pivotviewReports);
        }
        reportCollection.map(function (item: any): void {
            if (args.reportName === item.reportName) {
                args.report = item.report;
            }
        });
        if (args.report) {
            this.pivotObj.dataSourceSettings = JSON.parse(args.report).dataSourceSettings;
        }
    }
    removeReport(args: any) {
        let reportCollection: any[] = [];
        if (localStorage.pivotviewReports && localStorage.pivotviewReports !== "") {
            reportCollection = JSON.parse(localStorage.pivotviewReports);
        }
        for (let i: number = 0; i < reportCollection.length; i++) {
            if (reportCollection[i].reportName === args.reportName) {
                reportCollection.splice(i, 1);
            }
        }
        if (localStorage.pivotviewReports && localStorage.pivotviewReports !== "") {
            localStorage.pivotviewReports = JSON.stringify(reportCollection);
        }
    }
    renameReport(args: any) {
        let reportsCollection: any[] = [];
        if (localStorage.pivotviewReports && localStorage.pivotviewReports !== "") {
            reportsCollection = JSON.parse(localStorage.pivotviewReports);
        }
        if (args.isReportExists) {
            for (let i: number = 0; i < reportsCollection.length; i++) {
                if (reportsCollection[i].reportName === args.rename) {
                    reportsCollection.splice(i, 1);
                }
            }
        }
        reportsCollection.map(function (item: any): any { if (args.reportName === item.reportName) { item.reportName = args.rename; } });
        if (localStorage.pivotviewReports && localStorage.pivotviewReports !== "") {
            localStorage.pivotviewReports = JSON.stringify(reportsCollection);
        }
    }
    newReport() {
        this.pivotObj.setProperties({ dataSourceSettings: { columns: [], rows: [], values: [], filters: [] } }, false);
    }
    epaneResize(args:any){
        console.log(args);
    }
    beforeToolbarRender(args: any) {
        // args.customToolbar.splice(6, 0, {
        //     type: 'Separator'
        // });
        // args.customToolbar.splice(9, 0, {
        //     type: 'Separator'
        // });
        args.customToolbar.splice(11, 0, {
          prefixIcon: 'e-menu-icon e-pivotview-excel-export e-icons', tooltipText: 'Pivot Excel Export',
          click: this.ExporttoExcel.bind(this),
          align: 'Right'
        });
    } 

    toolbarClick(args: any): void {
      debugger;
      //if (args.item.id === 'Grid_excelexport') { // 'Grid_excelexport' -> Grid component id + _ + toolbar item name
          this.grid.excelExport();
      //}
    }
 
    ExporttoExcel() {
      const headers = { 'content-type': 'application/json'}  

      //name: 'ShipCountry', caption: 'Ship Country'

      const pvRows=  this.pivotObj.dataSourceSettings.rows as IFieldOptions[];
      const pvColumns=this.pivotObj.dataSourceSettings.columns as IFieldOptions[];
      const pvFilters=this.pivotObj.dataSourceSettings.filters as IFieldOptions[];
      const pvValues=this.pivotObj.dataSourceSettings.values as IFieldOptions[];

      var pvSelectedRows=pvRows.map(function(a) {return {name: a.name,caption: a.caption,}});
      var pvSelectedColumns=pvColumns.map(function(a) {return {name: a.name,caption: a.caption,}});
      var pvSelectedFilters=pvFilters.map(function(a) {return {name: a.name,caption: a.caption,}});
      var pvSelectedValues=pvValues.map(function(a) {return {name: a.name,caption: a.caption,}});
        
      const body=JSON.stringify({Rows:pvSelectedRows,Columns:pvSelectedColumns,Filters:pvSelectedFilters, Values:pvSelectedValues});
      //console.log(pvSelectedRows);
      this.http.post('http://localhost:46534/WeatherForecast', body,{'headers':headers,responseType: 'arraybuffer'}) .subscribe((res) => {
        this.writeContents(res, 'SbuReport.xlsx', 'application/octet-stream'); // file extension
      });
      //console.log("Excel");
      //this.pivotGridObj.excelExport();
    }

    ngOnInit(): void {
      this.data = new DataManager({
        url: 'http://localhost:46534/WeatherForecast',
        adaptor: new WebApiAdaptor,
        offline: true,
        crossDomain: true
      });
      this.dataDG = this.data;

      this.pageSettings = { pageCount: 3 };
      this.filterSettings = { type: "Menu" };      
      this.toolbarOptionsDG = ['ExcelExport'];
      this.initialSort = {
          columns: [{ field: 'ProductName', direction: 'Ascending' }]
      };
  
        this.chartSettings = {
            title: 'Orders Analysis',
            chartSeries: { type: 'Column' },
            load: this.observable.subscribe(args => {
                let selectedTheme: string = location.hash.split('/')[1];
                selectedTheme = selectedTheme ? selectedTheme : 'Material';
                (args as ILoadedEventArgs).chart.theme = <ChartTheme>(selectedTheme.charAt(0).toUpperCase() +
                  selectedTheme.slice(1)).replace(/-dark/i, 'Dark').replace(/contrast/i, 'Contrast');
            }) as any
        } as ChartSettings;

        this.displayOption = { view: 'Both' } as DisplayOption;
        this.gridSettings = {
            //columnWidth: 140
        } as GridSettings;

        this.toolbarOptions = [
          //'New', 'Save', 'SaveAs', 'Rename', 'Remove', 'Load',
            'Grid', 'Chart', 'Export', 'SubTotal', 'GrandTotal', 'Formatting', 'FieldList'] as ToolbarItems[];

            this.dataSourceSettings = {
              dataSource: this.data,
              expandAll: false,
              rows: [{ name: 'ProductName', caption: 'Product Name' }],
              columns: [{ name: 'ShipCountry', caption: 'Ship Country' }, { name: 'ShipCity', caption: 'Ship City' }],
              formatSettings: [{ name: 'UnitPrice', format: 'C2', currency: 'EUR' }, {name: 'Total Price', format: 'C0'}],
              values: [{ name: 'Quantity',  caption: 'Quantity' }, { name: 'UnitPrice', caption: 'Unit Price' }],
              filters: [],
              // conditionalFormatSettings: [
              //   {
              //     value1: 30,
              //     value2: 50,
              //     conditions: 'Between',
              //     style: {
              //       backgroundColor: '#80cbc4',
              //       color: 'black',
              //       fontFamily: 'Tahoma',
              //       fontSize: '12px'
        
              //     }
              //   }
              //   ,
              //   {
              //     value1: 20,
              //     value2: 25,
              //     conditions: 'Between',
              //     style: {
              //       backgroundColor: '#f48fb1',
              //       color: 'black',
              //       fontFamily: 'Tahoma',
              //       fontSize: '12px'
        
              //     }
              //   }
              // ]
            };
            //this.pivotObj.height='460'
      }
    writeContents(content:any, fileName:any, contentType:any) {
      const a = document.createElement('a');
      const file = new Blob([content], {type: contentType});
      a.href = URL.createObjectURL(file);
      a.download = fileName;
      a.click();
    }
    
    eventCheck(event:any){
      this.showPVGrid=event.target.checked;
    }

    

    public dataA: { [key: string]: Object }[] = [{"id":"36","dimensions":"H4_NAME"},{"id":"50","dimensions":"ITEM_TYPE"},{"id":"61","dimensions":"ATT3"},{"id":"65","dimensions":"HANGER"},{"id":"78","dimensions":"SELL_THRU_PER"},{"id":"91","dimensions":"EVENT"},{"id":"95","dimensions":"WOW_FLAG"},{"id":"105","dimensions":"KWT_SP"},{"id":"113","dimensions":"COMMENT_DESC"},{"id":"14","dimensions":"PIS_DATE"},{"id":"30","dimensions":"H1_NAME"},{"id":"35","dimensions":"H4"},{"id":"49","dimensions":"ITEMDESC"},{"id":"64","dimensions":"STORY"},{"id":"74","dimensions":"BUYER_SP"},{"id":"81","dimensions":"AVG_COST"},{"id":"87","dimensions":"CONV_FACT_AED"},{"id":"96","dimensions":"MASTER_CARTON"},{"id":"104","dimensions":"KSA_SP"},{"id":"106","dimensions":"OMN_SP"},{"id":"108","dimensions":"UAE_SP"},{"id":"111","dimensions":"FIBER_ACTUAL_COMP"},{"id":"10","dimensions":"FIXTURE"},{"id":"7","dimensions":"MANU_COUNTRY"},{"id":"9","dimensions":"SUPPINV"},{"id":"16","dimensions":"ENDSHIPDT_HDR"},{"id":"17","dimensions":"LINESTARTSHIPDT"},{"id":"21","dimensions":"PAY_TERM_CODE"},{"id":"26","dimensions":"AGENT_NAME2"},{"id":"48","dimensions":"ITEMNAME"},{"id":"56","dimensions":"ITEMSTYLE"},{"id":"60","dimensions":"ATT2"},{"id":"70","dimensions":"GRM"},{"id":"84","dimensions":"PUR_PRICE"},{"id":"89","dimensions":"FUTURE_ATTRIBUTE_1"},{"id":"98","dimensions":"INDICATOR_365"},{"id":"99","dimensions":"PHASE_IN_DATE"},{"id":"4","dimensions":"SUPP_ADDR"},{"id":"6","dimensions":"COUNTRY_ORIGIN"},{"id":"15","dimensions":"STARTSHIPDT_HDR"},{"id":"19","dimensions":"BUDGET_DATE_HDR"},{"id":"27","dimensions":"LOW_STATUS"},{"id":"29","dimensions":"H1"},{"id":"38","dimensions":"H5_NAME"},{"id":"42","dimensions":"SHIPSCH_REVISIONNO"},{"id":"43","dimensions":"ITEM_GROUP"},{"id":"44","dimensions":"PROCGRP"},{"id":"46","dimensions":"PARENTCODE"},{"id":"47","dimensions":"ITEMCODE"},{"id":"51","dimensions":"PROMOFLAG"},{"id":"52","dimensions":"STORE_GRID"},{"id":"57","dimensions":"FABRIC"},{"id":"58","dimensions":"FIBER_COMP"},{"id":"59","dimensions":"ATTR1"},{"id":"62","dimensions":"ATT4"},{"id":"66","dimensions":"ALIAS_NAME"},{"id":"68","dimensions":"REMARK"},{"id":"69","dimensions":"VM_CODE"},{"id":"75","dimensions":"BUYSP_AED"},{"id":"76","dimensions":"BH_SP"},{"id":"77","dimensions":"CREATOR"},{"id":"83","dimensions":"CURRENCY"},{"id":"88","dimensions":"CONV_FACT_USD"},{"id":"100","dimensions":"PHASE_ON_DATE"},{"id":"110","dimensions":"MODEL_TYPE"},{"id":"1","dimensions":"RAISE_LOCATION"},{"id":"8","dimensions":"MANUFACT"},{"id":"13","dimensions":"ORIGINAL_ETD"},{"id":"31","dimensions":"H2"},{"id":"34","dimensions":"H3_NAME"},{"id":"37","dimensions":"H5"},{"id":"55","dimensions":"COLOR"},{"id":"63","dimensions":"ATT5"},{"id":"86","dimensions":"PUR_PRICE_USD"},{"id":"94","dimensions":"MARKETING"},{"id":"112","dimensions":"WASH_CARE"},{"id":"3","dimensions":"SUPPCODE"},{"id":"5","dimensions":"BASE_COUNTRY"},{"id":"12","dimensions":"PO_DATE"},{"id":"23","dimensions":"PAY_METHOD"},{"id":"33","dimensions":"H3"},{"id":"39","dimensions":"SEASON"},{"id":"40","dimensions":"SHIPSCH"},{"id":"53","dimensions":"ITEM_LEVEL"},{"id":"67","dimensions":"BRAND"},{"id":"71","dimensions":"SUPP_STYLE"},{"id":"73","dimensions":"BUDGETTYPE"},{"id":"103","dimensions":"ITEM_REPEAT"},{"id":"109","dimensions":"KSA_HS_CODE"},{"id":"132","dimensions":"Size"},{"id":"20","dimensions":"BUDGET_DATE"},{"id":"24","dimensions":"SHIP_METHOD"},{"id":"25","dimensions":"AGENT_NAME"},{"id":"28","dimensions":"ORDER_TYPE"},{"id":"32","dimensions":"H2_NAME"},{"id":"41","dimensions":"SHIPSCH_NAME"},{"id":"54","dimensions":"SIZE_BREAKUP"},{"id":"72","dimensions":"BUYER"},{"id":"79","dimensions":"EXT_COMM"},{"id":"82","dimensions":"UOM"},{"id":"90","dimensions":"FUTURE_ATTRIBUTE_2"},{"id":"92","dimensions":"CHARACTER"},{"id":"97","dimensions":"FIFTH_GROUP"},{"id":"107","dimensions":"QTR_SP"},{"id":"125","dimensions":"PONO"},{"id":"45","dimensions":"PACKCODE"},{"id":"80","dimensions":"INT_COMM"},{"id":"85","dimensions":"PUR_PRICE_AED"},{"id":"93","dimensions":"RANGE"},{"id":"101","dimensions":"MARKDOWN_DATE"},{"id":"102","dimensions":"SUPPLIERSITEID"}];
    public dataB: { [key: string]: Object }[] = [{"id":"131","dimensions":"LANDED_UNIT_COST_AED","mandatory":"reqDim"},{"id":"2","dimensions":"SUPPLIER","mandatory":"reqDim"},{"id":"11","dimensions":"PO_REF","mandatory":"reqDim"},{"id":"18","dimensions":"LINEENDSHIPDT","mandatory":"reqDim"},{"id":"22","dimensions":"DELIVERY_TERM","mandatory":"reqDim"}];
    public fields: FieldSettingsModel = { text: 'dimensions'};
    public toolbarSettings: ToolbarSettingsModel = { items: ['moveAllTo', 'moveAllFrom']};
    public noRecordsTemplate = '<div class= "e-list-nrt"><span>No Dimension Selected</span></div>'
    public noRecordsTemplate1 = '<div class= "e-list-nrt"><span>All Dimensions Selected</span></div>'
 
    begin(args: any): void {
        if (args.eventName == "moveAllFrom"){
            console.log(args.eventName);
            args.cancel = true; 
            var items:{ [key: string]: Object }[]=Object.assign([], this.listObjB.getDataList());
            for(var i=0;i<items.length;i++){
                if(!items[i].hasOwnProperty('mandatory')){
                    this.listObjB.removeItem(items[i]);
                    this.listObjA.addItem(items[i]);
                } 
            }
            console.log(this.listObjB.getDataList());

        }
        else if(args.eventName == "moveAllTo"){
            console.log(args.eventName);
        }
      }

    MoveToB(args: any) {
        console.log(args);
        this.listObjB.addItem(args["items"][0]);
        this.listObjA.removeItem(args["items"][0]);
      }

    MoveToA(args: any) {
    console.log(args);
    if(args["items"][0]["mandatory"]!="reqDim"){
        this.listObjB.removeItem(args["items"][0]);
        this.listObjA.addItem(args["items"][0]);
        }
    }

    ShowGridsection(){
        this.currentmenu='';
        (<any>$('#id-item-details-modal')).modal('hide');

        (<any>$('#id-ace-settings-modal')).modal('hide');
        //$('#sidebar').addClass('collapsed');//collapsing sidebar;
        //$('#spacingDiv').addClass('tempSpacing'); //collapsing sidebar;
        //$('#sidebar, #id-item-details-modal').removeClass("disableddiv");   //disableDiv
        this.showGridSection=true; 

        Swal.fire({
            position: 'top-end',
            scrollbarPadding: false,
            type: 'info',
            icon: 'success',
            title: 'Your report generated',
            showConfirmButton: false,
            timer: 3000
          })
    }
    
}
