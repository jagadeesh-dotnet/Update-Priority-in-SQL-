import { Component, ElementRef, ViewChild } from '@angular/core';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'testapp2';
  @ViewChild('canvas',{static:true}) canvas: ElementRef | undefined;
  httpClient: any;

  // async captureScreenshot(url:any) {
      
  
  //   try {
  //     const screenshot = await html2canvas(document.body);
      
  //     const screenshotContext = canvas.getContext('2d');
  //     screenshotContext.drawImage(screenshot, 0, 0);
  //     // You can save the generated screenshot or perform further actions here
  //   } catch (error) {
  //     console.error('Failed to capture screenshot:', error);
  //   }
  // };

  captureAndDownloadScreenshot() {
    //url:any
    //var data=this.httpClient.get('https://ecssr.ae/ar/home', {responseType: "text"})

    const elementToCapture = document.body;
  
    html2canvas(elementToCapture,{scale: 5}).then((canvas) => {
      // Convert the canvas to a data URL
      const dataUrl = canvas.toDataURL();
  
      // Create a temporary <a> element to initiate the download
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = 'screenshot.png';
  
      // Trigger the download
      link.click();
    });
  }


  ngOnInit(){
    //this.captureAndDownloadScreenshot();
    debugger;
  }

  //waiting for the complete page to load

//   javascript
// const targetElement = document.getElementById('targetElement');

// const waitForImagesToLoad = () => {
//   return new Promise((resolve) => {
//     const images = targetElement.getElementsByTagName('img');
//     let loadedCount = 0;

//     const handleImageLoad = () => {
//       loadedCount++;
//       if (loadedCount === images.length) {
//         resolve();
//       }
//     };

//     for (const image of images) {
//       if (image.complete) {
//         handleImageLoad();
//       } else {
//         image.addEventListener('load', handleImageLoad);
//       }
//     }
//   });
// };

// const captureScreenshot = async () => {
//   await waitForImagesToLoad(); // Wait for the images to load
//   const screenshot = await html2canvas(targetElement);
//   // Further actions with the screenshot
// };

// captureScreenshot();
}
