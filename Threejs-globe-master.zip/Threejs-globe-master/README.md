# Globe - [Demo](https://nenadv91.github.io/Threejs-globe/)
Particles globe with countries in threejs

- Created with Three.js

### Preview
---
![Preview](https://raw.githubusercontent.com/nenadV91/Threejs-globe/master/previews/preview.png?raw=true "Home preview 1")

## Author
Nenad Vracar

## License
Licensed under MIT
