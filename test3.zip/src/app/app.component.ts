import { AfterViewChecked, Component, OnInit } from '@angular/core';
import MultiRootEditor from '@ckeditor/ckeditor5-build-multi-root';
//import MultiRootEditor from '@ckeditor/ckeditor5-build-multi-root';
import MultiRootEditorUIView from '@ckeditor/ckeditor5-editor-multi-root/src/multirooteditoruiview';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements  OnInit,AfterViewChecked{
  title = 'testapp';
  datajson={}; 

  ngOnInit(): void {

   this.editor
    this.datajson["content"]=document.getElementById( "content" );
    this.datajson["content1"]=document.getElementById( "content1" );

    console.log(this.datajson);
 
    this.addpage();

    
    // this.pages.push({
    //   htmlContent: "",
    //   full: false,
    // },)

    this.InitEditor();

    // MultiRootEditor.on( 'addRoot', ( evt, root ) => {
    //   const editableElement = editor.createEditable( root );
    
    //   // You may want to create a more complex DOM structure here.
    //   //
    //   // Alternatively, you may want to create a DOM structure before
    //   // calling `editor.addRoot()` and only append `editableElement` at
    //   // a proper place.
    
    //   document.querySelector( '#editors' ).appendChild( editableElement );
    // } );
  }


  InitEditor(){
    console.log(document.getElementById( "content-0" ));
    // this.editor
    //     .create( 
    //       {
    //         // Define roots / editable areas:
    //         //header: document.getElementById( 'header' ),
    //         'content-0': document.getElementById( 'content0' ),
    //         'content-1': document.getElementById( 'content1' )
    //         //leftSide: document.getElementById( 'left-side' ),
    //         //rightSide: document.getElementById( 'right-side' )
    //     }
    //     //this.datajson
    //     )
    //     .then( txteditor => {
    //         window.editor = txteditor;
             
    //           var changed = function () {
    //             alert("TEST");
    //           };
              
    //           txteditor.on('key', changed);
    //           txteditor.on('paste', changed);
    //           txteditor.on('afterCommandExec', changed);

    //         //   txteditor.on('mode', function() {
                 
    //         //         var editable = txteditor.editable();
    //         //         editable.attachListener(editable, 'input', function() {
    //         //             // Handle changes made in the source mode.
    //         //         });
                 
    //         // });

    //         txteditor.model.document.on( 'change:data', (evt, data) => {
    //           this.inputContent(txteditor.data.get( { rootName: 'content-0' } ), 0);
    //       } );

    //         // Append toolbar to a proper container.
    //         const toolbarContainer = document.getElementById( 'toolbar' );
    //         toolbarContainer.appendChild( txteditor.ui.view.toolbar.element );
    //         toolbarContainer.classList.add( 'sticky' );
    //         // Make toolbar sticky when the editor is focused.
    //         //editor.ui.focusTracker.on( 'change:isFocused', () => {
    //             //if ( editor.ui.focusTracker.isFocused ) {
    //          //       toolbarContainer.classList.add( 'sticky' );
    //             //} else {
    //             //    toolbarContainer.classList.remove( 'sticky' );
    //             //}
    //         //} );
    //     } )
    //     .catch( error => {
    //         console.error( 'There was a problem initializing the editor.', error );
    //     } );
    //     // this.editor.addRoot( 'myRoot', { data: '<p>Initial root data.</p>' } );

        
        
  }

  sizePage = {
    width: 21, //cm
    height: 29.7, //cm
    innerwidth:17,
    innerheight:25.6,
  };
  paddingPage = {
    top: 2, //cm
    right: 2, //cm
    bottom: 2, //cm
    left: 2, //cm
  };
  pages = [
  ];
  currentPage = 0;
  currentChar = null;

  runAfterViewChecked = false;
  public editor = MultiRootEditor;
  textEditor:any;
  clickPage(i) {
    this.currentPage = i;
  }

  
  inputContent(char, i) {
    // var element = document.getElementById("content-" + i);
    // var heightContent = (element!.offsetHeight * 2.54) / 96; // Convert pixels to cm
    // this.pages[i].htmlContent = element?element.innerHTML:'';
    // console.log(this.pages);
    // if (Number(heightContent.toFixed(1)) > this.sizePage.height) {
    //   this.currentChar = char;
    //   this.pages[i].full = true;
    //   if (!this.pages[i + 1]) {
    //     this.pages.push({
    //       htmlContent: "",
    //       full: false,
    //     });
        
    //     //this.editor.create({"content-1":document.getElementById("content-"+i)});
    //   }
      // this.currentPage = i + 1;
      // this.runAfterViewChecked = true;
    // }
  }

  addpage(){
    this.pages.push({
      htmlContent: "",
      full: false,
    },)

    this.runAfterViewChecked = true;
  }

  ngAfterViewChecked() { 

    if (this.runAfterViewChecked) {
    var contentHeader='content-'+(this.pages.length-1).toString();

    if(this.pages.length>1){
      // this.textEditor.addRoot( {
      //   // Define roots / editable areas:
      //   contentHeader: document.getElementById( contentHeader )
      // });

      this.runAfterViewChecked = false;
      
  //     this.textEditor.model.document.on( 'addRoot', (evt) => {
  //       console.log(evt);
  // } );

       this.textEditor.addRoot('content-'+(this.pages.length-1).toString(), { data: '<p>Initial root data.</p>' }  );
       

      // const toolbarContainer = document.getElementById( 'toolbar' );
      //     toolbarContainer.appendChild( this.textEditor.ui.view.toolbar.element );
          //toolbarContainer.classList.add( 'sticky' );

			// this.textEditor.createEditable( this.textEditor.model.document.getRoot( contentHeader ), contentHeader );

    }else{
      this.editor.create( {
        // Define roots / editable areas:
        'content-0': document.getElementById( contentHeader )
      }).then( txteditor => {
        window.editor = txteditor;
 
      //   txteditor.model.document.on( 'change:data', (evt, data) => {
           //this.inputContent(txteditor.data.get( { rootName: contentHeader } ), 0);
      // } );

      txteditor.on( 'addRoot', ( evt, root ) => {
        this.textEditor.createEditable( this.textEditor.model.document.getRoot( 'content-'+(this.pages.length-1).toString()) );
       
        const editableElement = this.textEditor.ui.view.editables['content-1'].element;
        editableElement.style['height']=25.6;
        editableElement.style['padding']=2;
        editableElement.style['width']=17;
        this.textEditor.editing.view.focus();
        document.getElementById( root.rootName).append(editableElement);
				 console.log(evt);
			});


        if(this.pages.length==1){
          // Append toolbar to a proper container.
          const toolbarContainer = document.getElementById( 'toolbar' );
          toolbarContainer.appendChild( txteditor.ui.view.toolbar.element );
          toolbarContainer.classList.add( 'sticky' );
        }
  this.textEditor=txteditor;

      });
    }
    this.runAfterViewChecked = false;
  }

//     document.getElementById("content-" + this.currentPage)!.focus();

//     for (let i = 0; i < this.pages.length; i++) {
//       this.datajson["content-" + i]=document.getElementById( "content-" + i );
  
//     }
// //this.InitEditor();
//     if (this.runAfterViewChecked) {
//       if (this.currentChar) {
//         var str = this.pages[this.currentPage - 1].htmlContent;
//         var indexLastCloseDiv = str.lastIndexOf("</div>");
//         var indexLastBr = str.lastIndexOf("<br>");
//         var lastChar = str[indexLastCloseDiv - 1];
//         if (indexLastBr != -1 && indexLastBr + 4 == indexLastCloseDiv)
//           lastChar = " ";

//         if (indexLastCloseDiv != -1)
//           str =
//             str.slice(0, indexLastCloseDiv - 1) + str.slice(indexLastCloseDiv);
//         else str = str.slice(0, str.length - 1);
//         this.pages[this.currentPage - 1].htmlContent = str;

//         if (this.pages[this.currentPage].htmlContent)
//           this.pages[this.currentPage].htmlContent =
//             lastChar + this.pages[this.currentPage].htmlContent;
//         else this.pages[this.currentPage].htmlContent = lastChar;
//       }

//       var element;
//       for (let i = 0; i < this.pages.length; i++) {
//         element = document.getElementById("content-" + i);
//         element.innerHTML = this.pages[i].htmlContent;
//         //this.datajson["content-" + i]=document.getElementById( "content-" + i );
//         //const editableElement = this.editor.createEditable('');
//       }
//       this.runAfterViewChecked = false;
//     }
    
  }
}