import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.scss']
})
export class ConfigComponent implements OnInit{
asrEngine: string = 'whisper';
  saving: boolean = false;
  message: string = '';

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.loadConfig();
  }

  loadConfig() {
    this.http.get<any>('http://localhost:8000/config/asr_engine').subscribe({
      next: (res) => {
        console.log('Loaded config:', res);
        this.asrEngine = res.value === 'whisper' ? 'whisper-base' : res.value;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Failed to load config', err);
        this.cdr.detectChanges();
      }
    });
  }

  saveConfig() {
    this.saving = true;
    this.http.post('http://localhost:8000/config/asr_engine', { value: this.asrEngine }).subscribe({
      next: (res) => {
        console.log('Config saved response:', res);
        this.saving = false;
        this.message = 'Configuration saved successfully!';
        this.cdr.detectChanges();
        setTimeout(() => {
          this.message = '';
          this.cdr.detectChanges();
        }, 3000);
      },
      error: (err) => {
        this.saving = false;
        this.message = 'Error saving configuration: ' + err.message;
        console.error('Save config error:', err);
        this.cdr.detectChanges();
      }
    });
  }
}
