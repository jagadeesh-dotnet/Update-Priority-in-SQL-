import { ChangeDetectorRef, Component, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface RecordingSession {
    sessionId: string;
    recordingId: number;
    startTime: Date;
    isRecording: boolean;
    transcription: string;
}

@Component({
  selector: 'app-mic-recorder',
  templateUrl: './mic-recorder.component.html',
  styleUrls: ['./mic-recorder.component.scss']
})
export class MicRecorderComponent implements OnDestroy {
stationName = 'Microphone Recording';

    // Recording state
    session: RecordingSession | null = null;
    mediaRecorder: MediaRecorder | null = null;
    audioChunks: Blob[] = [];
    recordingTimer = 0;
    timerInterval: any = null;

    // UI state
    // UI state
    micPermissionGranted = true; // Assume granted or handled by browser prompt on start
    isRequesting = false;
    errorMsg = '';
    statusMsg = '';

    constructor(private http: HttpClient, private cdr: ChangeDetectorRef) { }

    async requestMicPermission() {
        console.log('requestMicPermission called');
        this.isRequesting = true;
        this.errorMsg = '';
        this.cdr.detectChanges();

        try {
            console.log('Requesting microphone access...');
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    channelCount: 1,
                    sampleRate: 16000,
                    echoCancellation: true,
                    noiseSuppression: true
                }
            });

            console.log('Microphone access granted!', stream);

            // Stop the stream immediately, we just needed permission
            stream.getTracks().forEach(track => track.stop());

            this.micPermissionGranted = true;
            this.statusMsg = 'Microphone access granted!';
            console.log('micPermissionGranted set to:', this.micPermissionGranted);
            this.cdr.detectChanges();
        } catch (err: any) {
            console.error('Microphone permission error:', err);
            this.errorMsg = 'Microphone access denied: ' + err.message;
            this.cdr.detectChanges();
        } finally {
            this.isRequesting = false;
            console.log('isRequesting set to false');
            this.cdr.detectChanges();
        }
    }

    async startRecording() {
        // Removed permission pre-check, will fail in try/catch if blocked
        try {
            this.errorMsg = '';
            this.statusMsg = 'Starting recording...';
            this.cdr.detectChanges();

            // Start backend session
            const response = await this.http.post<any>('http://localhost:8000/recorder/mic/start', {
                station_name: this.stationName
            }).toPromise();

            this.session = {
                sessionId: response.session_id,
                recordingId: response.recording_id,
                startTime: new Date(),
                isRecording: true,
                transcription: ''
            };

            // Get microphone stream
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    channelCount: 1,
                    sampleRate: 16000,
                    echoCancellation: true,
                    noiseSuppression: true
                }
            });

            // Create MediaRecorder
            this.mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm'
            });

            this.audioChunks = [];

            this.mediaRecorder.ondataavailable = async (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);

                    // Upload chunk to backend
                    await this.uploadChunk(event.data);
                }
            };

            this.mediaRecorder.onstop = () => {
                stream.getTracks().forEach(track => track.stop());
                this.cdr.detectChanges();
            };

            // Start recording and request data every 2 seconds
            this.mediaRecorder.start(2000);

            // Start timer
            this.recordingTimer = 0;
            this.timerInterval = setInterval(() => {
                this.recordingTimer++;
                this.cdr.detectChanges();
            }, 1000);

            this.statusMsg = 'Recording...';
            this.cdr.detectChanges();

        } catch (err: any) {
            this.errorMsg = 'Failed to start recording: ' + err.message;
            console.error('Recording error:', err);
            this.session = null;
            this.cdr.detectChanges();
        }
    }

    async uploadChunk(chunk: Blob) {
        if (!this.session) return;

        try {
            const formData = new FormData();
            formData.append('file', chunk, 'chunk.webm');

            await this.http.post(
                `http://localhost:8000/recorder/mic/upload-chunk/${this.session.sessionId}`,
                formData
            ).toPromise();

            console.log('Chunk uploaded successfully');
        } catch (err) {
            console.error('Error uploading chunk:', err);
        }
    }

    async stopRecording() {
        if (!this.session || !this.mediaRecorder) return;

        try {
            this.statusMsg = 'Stopping recording...';
            this.cdr.detectChanges();

            // Stop media recorder
            this.mediaRecorder.stop();

            // Stop timer
            if (this.timerInterval) {
                clearInterval(this.timerInterval);
                this.timerInterval = null;
            }

            // Wait a bit for final chunks
            await new Promise(resolve => setTimeout(resolve, 500));

            // Finalize recording on backend
            const response = await this.http.post<any>(
                `http://localhost:8000/recorder/mic/stop/${this.session.sessionId}`,
                {}
            ).toPromise();

            this.statusMsg = 'Recording saved! Processing transcription...';

            // Reset state
            this.session = null;
            this.mediaRecorder = null;
            this.audioChunks = [];
            this.recordingTimer = 0;
            this.cdr.detectChanges();

            // Clear status after a delay
            setTimeout(() => {
                this.statusMsg = '';
                this.cdr.detectChanges();
            }, 3000);

        } catch (err: any) {
            this.errorMsg = 'Failed to stop recording: ' + err.message;
            console.error('Stop recording error:', err);
            this.cdr.detectChanges();
        }
    }

    formatTime(seconds: number): string {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    ngOnDestroy() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
        }
        if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
            this.mediaRecorder.stop();
        }
    }
}
