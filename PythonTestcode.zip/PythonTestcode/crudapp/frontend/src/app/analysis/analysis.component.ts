import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-analysis',
  templateUrl: './analysis.component.html',
  styleUrls: ['./analysis.component.scss']
})
export class AnalysisComponent {
 analysis: any = null;
  recordingId: string | null = null;
  loading: boolean = true;

  error: string = '';

  @ViewChild('audioPlayer') audioPlayer!: ElementRef<HTMLAudioElement>;

  constructor(private http: HttpClient, private route: ActivatedRoute, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.recordingId = this.route.snapshot.paramMap.get('id');
    if (this.recordingId) {
      this.fetchAnalysis();
    }
  }

  fetchAnalysis() {
    console.log('Fetching analysis for ID:', this.recordingId);
    this.http.get<any>(`http://localhost:8000/analysis/${this.recordingId}`).subscribe({
      next: (res) => {
        console.log('Received analysis data:', res);
        this.analysis = res;
        this.loading = false;
        this.error = '';
        this.cdr.detectChanges();

        // Continue polling if not completed
        if (this.analysis.status !== 'completed') {
          console.log('Status is not completed, polling again in 5s...');
          setTimeout(() => this.fetchAnalysis(), 5000);
        }
      },
      error: (err) => {
        console.error('Error fetching analysis:', err);
        this.error = 'Failed to load analysis. Recording might be initializing.';
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  getAudioUrl(filePath: string): string {
    if (!filePath) return '';
    // Convert backend path (e.g., recordings/file.wav) to URL
    const fileName = filePath.split(/[\\/]/).pop();
    return `http://localhost:8000/recordings/${fileName}`;
  }

  getSentimentLabel(score: number): string {
    if (score >= 0.05) return 'Positive';
    if (score <= -0.05) return 'Negative';
    return 'Neutral';
  }

  getSentimentClass(score: number): string {
    if (score >= 0.05) return 'sentiment-positive';
    if (score <= -0.05) return 'sentiment-negative';
    return 'sentiment-neutral';
  }

  seekAudio(startTime: number) {
    if (this.audioPlayer && this.audioPlayer.nativeElement) {
      this.audioPlayer.nativeElement.currentTime = startTime;
      this.audioPlayer.nativeElement.play();
    }
  }
}
