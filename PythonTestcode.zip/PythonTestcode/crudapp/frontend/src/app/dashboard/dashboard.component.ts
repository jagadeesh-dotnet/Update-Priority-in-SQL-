import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
recordings: any[] | null = [];
  isLoading = false;
  errorMsg = '';

  // Upload properties
  selectedFile: File | null = null;
  isUploading = false;
  uploadStatus = '';

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.fetchRecordings(true);
    setInterval(() => this.fetchRecordings(), 5000);
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      this.uploadStatus = '';
    }
  }

  uploadFile() {
    if (!this.selectedFile) return;

    this.isUploading = true;
    this.uploadStatus = 'Uploading...';

    const formData = new FormData();
    formData.append('file', this.selectedFile);

    this.http.post('http://localhost:8000/recorder/upload', formData).subscribe({
      next: (res: any) => {
        console.log('Upload success:', res);
        this.isUploading = false;
        this.uploadStatus = 'Upload successful! Processing queued.';
        this.selectedFile = null;
        // Reset file input if accessible, or just let user pick again
        // We'll just refresh list
        this.fetchRecordings();
      },
      error: (err) => {
        console.error('Upload error:', err);
        this.isUploading = false;
        this.uploadStatus = 'Error uploading file: ' + (err.error?.detail || err.message);
      }
    });
  }

  fetchRecordings(isInitial = false) {
    if (isInitial) this.isLoading = true;
    console.log('Fetching recordings status... (initial:', isInitial, ')');
    this.http.get<any[]>('http://localhost:8000/recorder/getRecordings').subscribe({
      next: (res) => {
        console.log('Received recordings:', res);
        this.recordings = res || [];
        this.isLoading = false;
        this.errorMsg = '';
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error fetching recordings:', err);
        this.isLoading = false;
        this.errorMsg = 'Failed to fetch recordings. Is the backend running?';
        this.cdr.detectChanges();
      }
    });
  }
}
