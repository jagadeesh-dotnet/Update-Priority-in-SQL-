
interface RecordingSession2 {
    sessionId: string;
    recordingId: number;
    startTime: Date;
    isRecording: boolean;
    transcription: string;
}
