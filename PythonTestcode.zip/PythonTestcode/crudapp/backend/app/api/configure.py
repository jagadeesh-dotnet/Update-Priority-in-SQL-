from fastapi import APIRouter,Depends,HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.entities import models
from app.core.database import get_db

router = APIRouter(prefix="/config", tags=["Configuration"])

class ConfigUpdate(BaseModel):
    value: str

@router.get("/")
async def get_all_configs(db: Session = Depends(get_db)):
    configs = db.query(models.SystemConfig).all()
    return {c.key: c.value for c in configs}

@router.get("/{key}")
async def get_config(key: str, db: Session = Depends(get_db)):
    config = db.query(models.SystemConfig).filter(models.SystemConfig.key == key).first()
    if not config:
        # Provide default for engine if not set
        if key == "asr_engine":
            return {"key": "asr_engine", "value": "whisper"}
        raise HTTPException(status_code=404, detail="Config not found")
    return config

@router.post("/{key}")
async def update_config(key: str, update: ConfigUpdate, db: Session = Depends(get_db)):
    config = db.query(models.SystemConfig).filter(models.SystemConfig.key == key).first()
    if not config:
        config = models.SystemConfig(key=key, value=update.value)
        db.add(config)
    else:
        config.value = update.value
    
    print(f"Updating config {key} to {update.value}")
    db.commit()
    db.refresh(config)
    return config
