
import datetime
import os
import shutil
from fastapi import APIRouter,Depends,HTTPException,UploadFile,File
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.entities import models
import uuid
 
from app.core.database import get_db
from app.services.recorder_service import recorder_service

router = APIRouter(prefix="/recorder", tags=["Recorder"])


class MicRecordingRequest(BaseModel):
    station_name: str = "Microphone Recording"
    
@router.get("/getRecordings")
def get_recordings(db: Session = Depends(get_db)):
    recordings = db.query(models.Recording).order_by(models.Recording.start_time.desc()).all()
    return recordings


@router.post("/upload")
async def upload_audio_file(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Upload an audio file for transcription"""
    try:
        # Generate unique filename
        filename = f"{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:8]}_{file.filename}"
        filepath = os.path.join("recordings", filename)
        
        # Save file
        with open(filepath, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        # Create database record
        recording = models.Recording(
            radio_station="Uploaded File",
            start_time=datetime.datetime.now(),
            status="pending",
            source_type="upload",
            file_path=filepath,
            filename=file.filename,
            duration=0 # Transcriber will handle true duration later? Or we could calculate it now.
        )
        db.add(recording)
        db.commit()
        db.refresh(recording)
        
        return {
            "message": "File uploaded successfully and queued for processing",
            "recording_id": recording.id,
            "filename": filename
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Microphone recording endpoints
@router.post("/mic/start")
async def start_mic_recording(request: MicRecordingRequest, db: Session = Depends(get_db)):
    """Start a new microphone recording session"""
    try:
        session_id, filepath = recorder_service.start_mic_recording(request.station_name)
        
        # Create database record
        recording = models.Recording(
            radio_station=request.station_name,
            start_time=datetime.datetime.now(),
            status="recording",
            source_type="microphone",
            session_id=session_id,
            file_path=filepath
        )
        db.add(recording)
        db.commit()
        db.refresh(recording)
        
        return {
            "session_id": session_id,
            "recording_id": recording.id,
            "message": "Microphone recording started"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/mic/upload-chunk/{session_id}")
async def upload_audio_chunk(session_id: str, file: UploadFile = File(...)):
    """Upload an audio chunk for an active recording session"""
    try:
        audio_data = await file.read()
        success = recorder_service.append_audio_chunk(session_id, audio_data)
        
        if not success:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return {"message": "Chunk uploaded successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/mic/stop/{session_id}")
async def stop_mic_recording(session_id: str, db: Session = Depends(get_db)):
    """Stop microphone recording and trigger transcription"""
    try:
        filepath = recorder_service.finalize_mic_recording(session_id)
        
        if not filepath:
            raise HTTPException(status_code=404, detail="Session not found")
        
        # Update database record
        recording = db.query(models.Recording).filter(
            models.Recording.session_id == session_id
        ).first()
        
        if not recording:
            raise HTTPException(status_code=404, detail="Recording not found in database")
        
        # Calculate duration
        duration = (datetime.datetime.now() - recording.start_time).total_seconds()
        recording.duration = duration
        recording.status = "pending"
        db.commit()
        
        # Trigger transcription processing - MOVED TO SCHEDULER
        # process_recording(recording.id)
        
        return {
            "message": "Recording stopped and queued for processing",
            "recording_id": recording.id,
            "filepath": filepath
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))