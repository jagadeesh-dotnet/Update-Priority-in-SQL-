from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from pydantic import BaseModel
from typing import List, Optional
from app.entities import models

router = APIRouter(prefix="/analysis", tags=["Analysis"])


class DiarizationSchema(BaseModel):
    speaker_id: str
    start_time: float
    end_time: float
    text_segment: Optional[str]

    class Config:
        from_attributes = True

class TranscriptionSchema(BaseModel):
    id: int
    text: str
    language: str
    sentiment_score: float
    engine: str
    diarization_data: List[DiarizationSchema]

    class Config:
        from_attributes = True

class AnalysisResponse(BaseModel):
    id: int
    radio_station: str
    file_path: Optional[str]
    status: str
    start_time: str
    transcription: Optional[TranscriptionSchema]

    class Config:
        from_attributes = True

@router.get("/{recording_id}", response_model=AnalysisResponse)
async def get_analysis(recording_id: int, db: Session = Depends(get_db)):
    recording = db.query(models.Recording).filter(models.Recording.id == recording_id).first()
    if not recording:
        raise HTTPException(status_code=404, detail="Recording not found")
    
    # Transcription might be null if still recording/pending
    transcription = db.query(models.Transcription).filter(models.Transcription.recording_id == recording_id).first()
    
    return {
        "id": recording.id,
        "radio_station": recording.radio_station,
        "file_path": recording.file_path,
        "status": recording.status,
        "start_time": recording.start_time.isoformat(),
        "transcription": transcription
    }