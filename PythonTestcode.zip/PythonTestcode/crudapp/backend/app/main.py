from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.health import router as health_router
from app.api.recorder import router as recorder_router
from app.api.configure import router as configure_router
from app.api.analysis import router as analysis_router
import os
from app.services.scheduler_service import scheduler
from fastapi.staticfiles import StaticFiles

# Ensure recordings directory exists
if not os.path.exists("recordings"):
    os.makedirs("recordings")

app = FastAPI(
    title="Audio Transcripting FastAPI",
    version="1.0.0"
)

allowOrigins = [
    "http://localhost:4200",
]



app.add_middleware(
    CORSMiddleware,
    allow_origins=allowOrigins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Audio Transcription System API is running"}

# Serve recordings
app.mount("/recordings", StaticFiles(directory="recordings"), name="recordings")

app.include_router(health_router)
app.include_router(recorder_router)
app.include_router(configure_router)
app.include_router(analysis_router)
