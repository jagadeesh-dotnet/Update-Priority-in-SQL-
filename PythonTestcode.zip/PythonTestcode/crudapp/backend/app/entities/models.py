from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey, Text, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import datetime
import enum

Base = declarative_base()

class EngineType(enum.Enum):
    WHISPER = "whisper"
    VOSK = "vosk"

class SystemConfig(Base):
    __tablename__ = "system_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(50), unique=True, index=True)
    value = Column(String(255))
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

class Recording(Base):
    __tablename__ = "recordings"
    
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(255), index=True)
    file_path = Column(String(500))
    start_time = Column(DateTime, index=True)
    duration = Column(Float)
    radio_station = Column(String(100))
    status = Column(String(50)) # e.g., "recording", "pending_transcription", "completed"
    source_type = Column(String(20), default="stream") # "stream" or "microphone"
    session_id = Column(String(100), nullable=True) # For active microphone sessions
    partial_transcription = Column(Text, nullable=True) # Live transcription text
    
    transcriptions = relationship("Transcription", back_populates="recording")

class Transcription(Base):
    __tablename__ = "transcriptions"
    
    id = Column(Integer, primary_key=True, index=True)
    recording_id = Column(Integer, ForeignKey("recordings.id"))
    engine = Column(String(50)) # whisper or vosk
    text = Column(Text)
    language = Column(String(10))
    sentiment_score = Column(Float)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    recording = relationship("Recording", back_populates="transcriptions")
    diarization_data = relationship("Diarization", back_populates="transcription")

class Diarization(Base):
    __tablename__ = "diarization"
    
    id = Column(Integer, primary_key=True, index=True)
    transcription_id = Column(Integer, ForeignKey("transcriptions.id"))
    speaker_id = Column(String(50))
    start_time = Column(Float)
    end_time = Column(Float)
    text_segment = Column(Text)
    
    transcription = relationship("Transcription", back_populates="diarization_data")
