from apscheduler.schedulers.background import BackgroundScheduler
from app.services.recorder_service import recorder_service
from app.services.transcription_service import transcription_service
from app.services.nlp_service import nlp_service
from app.core.database import SessionLocal
from app.entities import models
import datetime
import threading

processing_lock = threading.Lock()

scheduler = BackgroundScheduler()

def process_recording(recording_id: int):
    print(f"--- Starting processing for recording ID: {recording_id} ---")
    db = SessionLocal()
    try:
        recording = db.query(models.Recording).filter(models.Recording.id == recording_id).first()
        if not recording:
            print(f"Recording {recording_id} not found.")
            return

        # Get configured engine
        config = db.query(models.SystemConfig).filter(models.SystemConfig.key == "asr_engine").first()
        engine = config.value if config else "whisper"
        print(f"ASR Engine: {engine}")

        # Transcribe
        print(f"Transcribing {recording.file_path}...")
        result = transcription_service.transcribe(recording.file_path, engine=engine)
        text = result["text"]
        language = result["language"]
        print(f"Transcribed Text: {text[:100]}...")
        
        # Diarize
        print("Running diarization...")
        diarization_segments = transcription_service.diarize(recording.file_path)
        print(f"Found {len(diarization_segments)} speaker segments.")
        
        # NLP Analysis
        print("Analyzing sentiment...")
        sentiment = nlp_service.analyze_sentiment(text)
        
        # Save transcription
        transcription = models.Transcription(
            recording_id=recording.id,
            engine=engine,
            text=text,
            language=language,
            sentiment_score=sentiment
        )
        db.add(transcription)
        db.flush() 

        # Merge Whisper segments with Diarization
        # Whisper segments: [{'text': '...', 'start': 0.0, 'end': 2.0}, ...]
        # Diarization segments: [{'speaker': 'SPEAKER_00', 'start': 0.5, 'end': 4.0}, ...]
        
        whisper_segments = result.get("segments", [])
        
        if not whisper_segments:
             # Fallback if no segments (e.g. Vosk or short audio), just store speakers
             for seg in diarization_segments:
                diar_entry = models.Diarization(
                    transcription_id=transcription.id,
                    speaker_id=seg["speaker"],
                    start_time=seg["start"],
                    end_time=seg["end"],
                    text_segment=""
                )
                db.add(diar_entry)
        else:
            # Simple alignment: Assign speaker to text segment based on midpoint
            for w_seg in whisper_segments:
                w_start = w_seg["start"]
                w_end = w_seg["end"]
                w_mid = (w_start + w_end) / 2
                w_text = w_seg["text"]

                # Find speaker active at w_mid
                assigned_speaker = "Unknown"
                
                # Check overlaps
                # We can optimize this, but O(N*M) is fine for short clips. 
                # Better: pick speaker with max overlap.
                
                best_overlap = 0
                for d_seg in diarization_segments:
                    d_start = d_seg["start"]
                    d_end = d_seg["end"]
                    
                    # Calculate overlap
                    overlap_start = max(w_start, d_start)
                    overlap_end = min(w_end, d_end)
                    overlap = max(0, overlap_end - overlap_start)
                    
                    if overlap > best_overlap:
                        best_overlap = overlap
                        assigned_speaker = d_seg["speaker"]
                
                # Create entry
                diar_entry = models.Diarization(
                    transcription_id=transcription.id,
                    speaker_id=assigned_speaker,
                    start_time=w_start,
                    end_time=w_end,
                    text_segment=w_text.strip()
                )
                db.add(diar_entry)

        recording.status = "completed"
        db.commit()
        print(f"--- Finished processing recording {recording_id} ---")
    except Exception as e:
        print(f"!!! Error processing recording {recording_id}: {e}")
        db.rollback()
    finally:
        db.close()

def check_pending_recordings():
    """Check for pending recordings and process them."""
    if not processing_lock.acquire(blocking=False):
        print("Scheduler is already processing recordings. Skipping this run.")
        return

    try:
        # print("Checking for pending recordings...") # Reduce noise
        db = SessionLocal()
        try:
            # pending_transcription is the status we decided on in the plan ("pending")
            # specific string "pending" was mentioned in plan prompt: "status pending"
            # Let's stick to "pending" to match user request, but code had "pending_transcription". 
            # I will change code to use "pending" in recorder_router.py, so here I search for "pending".
            pending_recordings = db.query(models.Recording).filter(models.Recording.status == "pending").all()
            
            if pending_recordings:
                print(f"Found {len(pending_recordings)} pending recordings.")
            
            for recording in pending_recordings:
                # First, update status to 'processing' so no other worker picks it up?
                # For now, simplistic: just process. 
                # Ideally better locking, but this is simple scheduler.
                process_recording(recording.id)
                
        except Exception as e:
            print(f"Error checking pending recordings: {e}")
        finally:
            db.close()
    finally:
        processing_lock.release()
        
scheduler.add_job(check_pending_recordings, 'interval', minutes=1)
scheduler.start()
