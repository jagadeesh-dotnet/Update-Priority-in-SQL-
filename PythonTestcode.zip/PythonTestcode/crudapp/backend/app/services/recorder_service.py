import os
import subprocess
import uuid
import datetime
from typing import Optional

class RecorderService:
    def __init__(self, output_dir: str = "recordings"):
        self.output_dir = output_dir
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        self.processes = {}
        self.mic_sessions = {}  # Store active microphone recording sessions



    def start_mic_recording(self, station_name: str = "Microphone") -> tuple[str, str]:
        """Start a new microphone recording session"""
        session_id = str(uuid.uuid4())
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{station_name}_{timestamp}.wav"
        temp_filename = f"{station_name}_{timestamp}_temp.webm"
        filepath = os.path.join(self.output_dir, filename).replace("\\", "/")
        temp_filepath = os.path.join(self.output_dir, temp_filename).replace("\\", "/")
        
        # Create temporary WebM file to collect chunks
        temp_file = open(temp_filepath, 'wb')
        
        self.mic_sessions[session_id] = {
            'filepath': filepath,
            'temp_filepath': temp_filepath,
            'filename': filename,
            'temp_file': temp_file,
            'start_time': datetime.datetime.now(),
            'chunks_received': 0
        }
        
        print(f"Started microphone recording session {session_id}: {filepath}")
        return session_id, filepath

    def append_audio_chunk(self, session_id: str, audio_data: bytes) -> bool:
        """Append audio chunk to active recording session"""
        if session_id not in self.mic_sessions:
            print(f"Session {session_id} not found")
            return False
        
        try:
            session = self.mic_sessions[session_id]
            session['temp_file'].write(audio_data)
            session['chunks_received'] += 1
            return True
        except Exception as e:
            print(f"Error appending audio chunk: {e}")
            return False

    def finalize_mic_recording(self, session_id: str) -> Optional[str]:
        """Finalize microphone recording and return file path"""
        if session_id not in self.mic_sessions:
            print(f"Session {session_id} not found")
            return None
        
        try:
            session = self.mic_sessions[session_id]
            session['temp_file'].close()
            temp_filepath = session['temp_filepath']
            filepath = session['filepath']
            
            print(f"Converting WebM to WAV: {temp_filepath} -> {filepath}")
            
            # Convert WebM to WAV using FFmpeg
            ffmpeg_path = r"C:\Users\jagad\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-8.0.1-full_build\bin\ffmpeg.exe"
            
            command = [
                ffmpeg_path, "-y",
                "-i", temp_filepath,
                "-acodec", "pcm_s16le",
                "-ar", "16000",
                "-ac", "1",
                filepath
            ]
            
            result = subprocess.run(command, capture_output=True, text=True)
            
            if result.returncode != 0:
                print(f"FFmpeg conversion error: {result.stderr}")
                return None
            
            # Delete temporary WebM file
            if os.path.exists(temp_filepath):
                os.remove(temp_filepath)
            
            print(f"Finalized microphone recording: {filepath} ({session['chunks_received']} chunks)")
            del self.mic_sessions[session_id]
            
            return filepath
        except Exception as e:
            print(f"Error finalizing recording: {e}")
            return None

recorder_service = RecorderService()
