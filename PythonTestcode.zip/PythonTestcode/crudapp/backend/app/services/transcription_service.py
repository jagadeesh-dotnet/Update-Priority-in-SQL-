import os
import torch
from app.entities import models
from sqlalchemy.orm import Session
from app.core.database import SessionLocal
import langdetect

class TranscriptionService:
    def __init__(self):
        self.whisper_model = None
        self.whisper_model_size = None
        self.vosk_model = None
        self.vad_model = None
        self.diarization_pipeline = None

    def _load_whisper(self, model_size="base"):
        import whisper
        try:
            if self.whisper_model is None or self.whisper_model_size != model_size:
                print(f"Loading Whisper model: {model_size}...")
                self.whisper_model = whisper.load_model(model_size)
                self.whisper_model_size = model_size
            return self.whisper_model
        except Exception as e:
            print(f"Error loading Whisper: {e}")
            return None

    def _load_vosk(self):
        from vosk import Model
        try:
            if self.vosk_model is None:
                model_path = "llm-models/vosk-model-small-en-us-0.15"
                if not os.path.exists(model_path):
                    print(f"Vosk model not found at {model_path}")
                    return None
                self.vosk_model = Model(model_path)
            return self.vosk_model
        except Exception as e:
            print(f"Error loading Vosk: {e}")
            return None

    def _load_silero_vad(self):
        try:
            if self.vad_model is None:
                model, utils = torch.hub.load(repo_or_dir='snakers4/silero-vad',
                                            model='silero_vad',
                                            force_reload=False,
                                            onnx=True)
                self.vad_model = model
            return self.vad_model
        except Exception as e:
            print(f"Error loading Silero VAD: {e}")
            return None

    def _load_pyannote(self):
        try:
            from pyannote.audio import Pipeline
            if self.diarization_pipeline is None:
                # In air-gapped, this WILL fail unless pre-downloaded
                self.diarization_pipeline = Pipeline.from_pretrained(
                    "pyannote/speaker-diarization@2.1", 
                    use_auth_token=os.getenv("HF_AUTH_TOKEN")
                )
            return self.diarization_pipeline
        except Exception as e:
            print(f"Error loading Pyannote (Speaker Diarization): {e}")
            return None

    def detect_language(self, text: str) -> str:
        try:
            return langdetect.detect(text)
        except:
            return "unknown"

    def diarize(self, file_path: str):
        pipeline = self._load_pyannote()
        if not pipeline:
            return []
        
        # Run diarization
        diarization = pipeline(file_path)
        segments = []
        for turn, _, speaker in diarization.itertracks(yield_label=True):
            segments.append({
                "start": turn.start,
                "end": turn.end,
                "speaker": speaker
            })
        return segments

    def transcribe(self, file_path: str, engine: str = "whisper") -> dict:
        if engine.startswith("whisper"):
            # Parse model size from engine string (e.g., "whisper-medium" -> "medium")
            parts = engine.split("-")
            model_size = parts[1] if len(parts) > 1 else "base"
            
            model = self._load_whisper(model_size)
            result = model.transcribe(file_path)
            text = result["text"]
            language = result.get("language", self.detect_language(text))
            
            return {
                "text": text,
                "language": language,
                "segments": result.get("segments", [])
            }
        elif engine == "vosk":
            import wave
            import json
            from vosk import KaldiRecognizer
            
            model = self._load_vosk()
            if not model:
                return {"text": "Vosk model not loaded.", "language": "unknown"}
                
            wf = wave.open(file_path, "rb")
            rec = KaldiRecognizer(model, wf.getframerate())
            
            results = []
            segments = []
            
            # Track time
            total_frames = 0
            sample_rate = wf.getframerate()
            last_end_time = 0.0
            
            while True:
                data = wf.readframes(4000)
                if len(data) == 0:
                    break
                
                total_frames += len(data) // 2 # 2 bytes per sample (16-bit)
                current_time = total_frames / sample_rate
                
                if rec.AcceptWaveform(data):
                    res = json.loads(rec.Result())
                    text_chunk = res.get("text", "")
                    if text_chunk:
                        results.append(text_chunk)
                        segments.append({
                            "start": last_end_time,
                            "end": current_time,
                            "text": text_chunk
                        })
                        last_end_time = current_time
            
            res = json.loads(rec.FinalResult())
            text_chunk = res.get("text", "")
            if text_chunk:
                results.append(text_chunk)
                # For final result, end time is total duration
                segments.append({
                    "start": last_end_time,
                    "end": total_frames / sample_rate,
                    "text": text_chunk
                })

            text = " ".join(results)
            language = self.detect_language(text)
            
            return {
                "text": text,
                "language": language,
                "segments": segments
            }
        else:
            return {"text": "Unsupported engine.", "language": "unknown"}

transcription_service = TranscriptionService()
