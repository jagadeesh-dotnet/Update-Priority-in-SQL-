from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import re

class NLPService:
    def __init__(self):
        self.analyzer = SentimentIntensityAnalyzer()

    def analyze_sentiment(self, text: str) -> float:
        """Returns compound sentiment score (-1 to 1)"""
        if not text:
            return 0.0
        scores = self.analyzer.polarity_scores(text)
        return scores['compound']

    def extract_keywords(self, text: str, top_n: int = 5):
        """Simple keyword extraction (placeholder for TextRank)"""
        # Basic implementation: frequency based excluding short words
        words = re.findall(r'\w+', text.lower())
        stopwords = {"the", "and", "is", "of", "to", "in", "it", "that", "was", "for", "on", "are", "with", "as", "be", "at", "by", "this"}
        filtered_words = [w for w in words if w not in stopwords and len(w) > 3]
        
        freq = {}
        for w in filtered_words:
            freq[w] = freq.get(w, 0) + 1
            
        sorted_keywords = sorted(freq.items(), key=lambda x: x[1], reverse=True)
        return [k for k, v in sorted_keywords[:top_n]]

nlp_service = NLPService()
