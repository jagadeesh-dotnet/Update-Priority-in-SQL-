from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os
from dotenv import load_dotenv

load_dotenv()

# Example connection string for SQL Server on Windows
# Use DATABASE_URL from .env or fallback to local SQL Server or SQLite
DATABASE_URL = os.getenv("DATABASE_URL")

if DATABASE_URL:
    engine = create_engine(DATABASE_URL)
else:
    # Use the specific connection string provided by the user
    # Note: SQLAlchemy requires the connection string to be URL-encoded or in a specific format for pyodbc
    import urllib
    params = urllib.parse.quote_plus("Driver={ODBC Driver 17 for SQL Server};Server=JAGAM;Database=fm_intelligence;Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=yes;")
    conn_str = f"mssql+pyodbc:///?odbc_connect={params}"
    
    try:
        engine = create_engine(conn_str)
        # Test connection
        with engine.connect() as conn:
            pass
        print("Successfully connected to JAGAM MS SQL Server using Windows Authentication.")
    except Exception as e:
        print(f"CRITICAL: MS SQL Server connection failed: {e}")
        # Fail loudly instead of falling back to SQLite
        raise e

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
